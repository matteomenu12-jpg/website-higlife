/* eslint-disable @next/next/no-img-element */
const errors:Record<string,string>={
  'not-configured':'De beveiligde Discord-sleutel ontbreekt nog in Cloudflare.',
  'invalid-state':'De loginpoging is verlopen. Probeer opnieuw.',
  token:'Discord kon de login niet bevestigen. Controleer de OAuth2-instellingen.',
  profile:'Je Discord-profiel kon niet worden opgehaald.',
};

export default async function Login({searchParams}:{searchParams:Promise<{error?:string}>}){const {error}=await searchParams;return <main className="auth-page">
  <a className="back-link" href="/">← Terug naar de stad</a>
  <section className="auth-visual"><div className="auth-grid"/><span className="auth-index">HL/01</span><div><p className="eyebrow"><span/> VEILIGE DISCORD-LOGIN</p><h1>Één identiteit.<br/><em>Alle toegang.</em></h1><p>Log in om topics te maken, te reageren en jouw HighLife-profiel te gebruiken.</p></div></section>
  <section className="auth-panel"><div className="login-box"><img className="login-logo" src="/highlife-logo-animated.gif" alt="Bewegend HighLife Roleplay-logo"/><p className="kicker">HIGHLIFE IDENTITY</p><span className="soon-pill live-pill">LIVE</span><h2>Log in met Discord</h2><p>We gebruiken alleen je openbare Discord-ID, gebruikersnaam en profielfoto. Je wachtwoord blijft altijd bij Discord.</p>{error&&<p className="auth-error">{errors[error]||'De Discord-login kon niet worden voltooid.'}</p>}<a className="discord-login" href="/api/auth/discord"><span>◈</span> Doorgaan met Discord <b>→</b></a><small>Door in te loggen ga je akkoord met de communityregels.</small></div></section>
</main>}
