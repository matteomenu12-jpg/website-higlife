import type { Metadata } from 'next';
import { headers } from 'next/headers';
import { Rajdhani, Manrope } from 'next/font/google';
import './globals.css';
import './highlife.css';
import {MotionObserver} from '@/components/MotionObserver';
import {GlobalControls} from '@/components/GlobalControls';

const display = Rajdhani({ variable: '--font-display', subsets: ['latin'], weight: ['500','600','700'] });
const body = Manrope({ variable: '--font-body', subsets: ['latin'] });

export async function generateMetadata():Promise<Metadata>{
  const host=(await headers()).get('host')??'localhost:3000';
  const trusted=/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host)||host.endsWith('.chatgpt.site');
  const origin=trusted?`${host.startsWith('localhost')||host.startsWith('127.')?'http':'https'}://${host}`:'https://chatgpt.com';
  return { metadataBase:new URL(origin), title:'Highlife Roleplay', description:'Een Nederlandse FiveM roleplaycommunity waar ambitie, status en sterke verhalen samenkomen.', applicationName:'HighLife RP', icons:{icon:[{url:'/highlife-logo-animated.gif',sizes:'512x512',type:'image/gif'},{url:'/icon-192.png',sizes:'192x192',type:'image/png'}],apple:[{url:'/apple-touch-icon.png',sizes:'180x180',type:'image/png'}]}, appleWebApp:{capable:true,statusBarStyle:'black-translucent',title:'HighLife RP'}, manifest:'/manifest.webmanifest', openGraph:{title:'Highlife Roleplay',description:'Leef groots. Speel Highlife.',images:[{url:'/highlife-banner.jpg',width:1536,height:611,alt:'Highlife Roleplay skyline'}]}, twitter:{card:'summary_large_image',title:'Highlife Roleplay',description:'Leef groots. Speel Highlife.',images:['/highlife-banner.jpg']} };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="nl"><body className={`${display.variable} ${body.variable}`}><MotionObserver/><GlobalControls/>{children}</body></html>;
}
