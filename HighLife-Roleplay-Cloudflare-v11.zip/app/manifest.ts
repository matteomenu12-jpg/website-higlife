import type {MetadataRoute} from 'next';

export default function manifest():MetadataRoute.Manifest{
  return {
    name:'HighLife Roleplay',
    short_name:'HighLife RP',
    description:'De officiële HighLife Roleplay-community.',
    start_url:'/',
    display:'standalone',
    background_color:'#06191b',
    theme_color:'#0d7774',
    icons:[
      {src:'/highlife-logo-animated.gif',sizes:'512x512',type:'image/gif'},
      {src:'/icon-192.png',sizes:'192x192',type:'image/png'},
      {src:'/icon-512.png',sizes:'512x512',type:'image/png'},
    ],
  };
}
