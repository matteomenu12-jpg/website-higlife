import {SiteHeader} from '@/components/SiteHeader';
/* eslint-disable @next/next/no-img-element, @next/next/no-html-link-for-pages */

const stats = [['01', 'seizoen'], ['24/7', 'community'], ['100%', 'roleplay']];

export default function Home() {
  return (
    <main id="top" className="site-shell">
      <SiteHeader active="Home"/>

      <section className="hero">
        <div className="hero-glow" aria-hidden="true" />
        <div className="hero-copy">
          <p className="eyebrow"><span /> HIGHLIFE ROLEPLAY · SEIZOEN 01</p>
          <h1>Leef groots.<br/><em>Speel HighLife.</em></h1>
          <p className="lead">Een Nederlandse roleplaywereld vol ambitie, status en verhalen die blijven hangen. Maak naam in de stad en bepaal zelf hoe hoog je klimt.</p>
          <div className="hero-actions">
            <a className="primary-button" href="#join">Stap de stad in <span>→</span></a>
            <a className="ghost-button" href="/announcements">Bekijk stadsnieuws</a>
          </div>
        </div>
      </section>

      <section className="statbar" aria-label="Serverstatistieken">
        <p><b>HIGHLIFE/RP</b><span>SEIZOEN 01 · HOOFDSTUK I</span></p>
        {stats.map(([value,label]) => <p key={label}><strong>{value}</strong><span>{label}</span></p>)}
        <p className="scroll-hint"><span>SCROLL TO EXPLORE</span>↓</p>
      </section>
      <section className="manifesto" id="join">
        <div><p className="kicker">GEBOUWD VOOR VERHALEN</p><h2>De stad reageert<br/>op wat jij doet.</h2></div>
        <p>HighLife draait niet om winnen. Het draait om ambitie, relaties en personages die groeien. Elke dienst, onderneming en crew voegt iets toe aan een levende wereld.</p>
      </section>
      <section className="pillar-grid">
        <article><span>01 / WORLD</span><h3>Een economie met gewicht</h3><p>Van eerste loonstrook tot eigen onderneming. Geld opent deuren, maar reputatie houdt ze open.</p></article>
        <article><span>02 / STORIES</span><h3>Roleplay die verdergaat</h3><p>Afdelingen, bedrijven en onderwereldlijnen zijn ontworpen voor verhalen op de lange termijn.</p></article>
        <article><span>03 / PEOPLE</span><h3>Staff met duidelijke grenzen</h3><p>Elke staffrol krijgt alleen de rechten die nodig zijn. Besluiten blijven zichtbaar in het auditlog.</p></article>
      </section>
      <section className="pathways">
        <div><p className="eyebrow"><span/> KIES JE RICHTING</p><h2>Hoe hoog klim jij<br/>na zonsondergang?</h2><a className="ghost-button" href="/community">Ontdek de community →</a></div>
        <div className="path-list"><article><b>01</b><h3>Burger & ondernemer</h3><p>Bouw een netwerk, open een zaak en maak jezelf onmisbaar.</p></article><article><b>02</b><h3>Hulpdiensten</h3><p>Werk onder druk en neem beslissingen waar de hele stad op rekent.</p></article><article><b>03</b><h3>Onderwereld</h3><p>Vorm bondgenootschappen, neem risico’s en blijf één stap voor.</p></article></div>
      </section>
      <section className="city-showcase"><div className="city-showcase-head"><div><p className="kicker">BEELDEN UIT DE STAD</p><h2>HighLife<br/>in beweging.</h2></div><p>Van de kustlijn tot het centrum: iedere wijk vormt het decor voor nieuwe verhalen.</p></div><div className="city-showcase-grid"><figure><img src="/highlife-city-coast.webp" alt="Trein en vliegtuig aan de kust van HighLife"/><figcaption><span>01</span><b>De noordelijke route</b></figcaption></figure><figure><img src="/highlife-city-sunset.jpg" alt="HighLife skyline bij zonsondergang"/><figcaption><span>02</span><b>Downtown na zonsondergang</b></figcaption></figure><figure><img src="/highlife-city-district.jpg" alt="Moderne stadswijk van HighLife"/><figcaption><span>03</span><b>Een stad vol kansen</b></figcaption></figure></div></section>
      <section className="join-banner"><p className="kicker">HIGHLIFE WACHT OP JOU</p><h2>Je volgende hoofdstuk<br/>begint hier.</h2><div><a className="primary-button" href="/account">Open je account →</a><a className="ghost-button" href="/forum">Open het forum</a></div></section>
      <footer><a className="brand" href="/"><img className="brand-logo" src="/highlife-logo-animated.gif" alt="Bewegend HighLife-logo"/><span><b>HIGHLIFE</b><small>ROLEPLAY</small></span></a><p>Een onafhankelijke FiveM-community. Niet verbonden aan Rockstar Games of Cfx.re.</p><div><a href="/rules">Regels</a><a href="/announcements">Nieuws</a><a href="/community">Community</a><a href="/account">Account</a></div></footer>
    </main>
  );
}
