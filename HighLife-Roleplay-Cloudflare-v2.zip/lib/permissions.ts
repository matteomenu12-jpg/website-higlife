export const PERMISSIONS = ['staff.access','announcements.create','announcements.edit','announcements.delete','announcements.publish','members.view','members.assign_roles','roles.manage','moderation.view','audit.view'] as const;
export type Permission = typeof PERMISSIONS[number];
export const DEFAULT_ROLES = [
  { slug:'owner', name:'Eigenaar', color:'#f6b94a', level:100, permissions:['*'] },
  { slug:'administrator', name:'Administrator', color:'#ff7657', level:80, permissions:['staff.access','announcements.create','announcements.edit','announcements.delete','announcements.publish','members.view','members.assign_roles','roles.manage','moderation.view','audit.view'] },
  { slug:'moderator', name:'Moderator', color:'#58a6ff', level:50, permissions:['staff.access','members.view','moderation.view'] },
  { slug:'communications', name:'Communicatie', color:'#ff3fbd', level:40, permissions:['staff.access','announcements.create','announcements.edit','announcements.publish'] },
];
export function hasPermission(permissions:string[], permission:Permission) { return permissions.includes('*') || permissions.includes(permission); }
