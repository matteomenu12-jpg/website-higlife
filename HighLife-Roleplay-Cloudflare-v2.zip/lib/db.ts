import { env } from 'cloudflare:workers';
import { DEFAULT_ROLES } from './permissions';
export type SessionUser = { id:number; discordId:string; username:string; displayName:string; avatar:string|null; roles:string[]; permissions:string[]; maxLevel:number };
export function database(){ return (env as unknown as {DB:D1Database}).DB; }
let initialized = false;
export async function ensureDb(){
  if(initialized) return; const db=database();
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, discord_id TEXT NOT NULL UNIQUE, username TEXT NOT NULL, display_name TEXT NOT NULL, avatar TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS roles (id INTEGER PRIMARY KEY AUTOINCREMENT, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL, color TEXT NOT NULL, level INTEGER NOT NULL, permissions TEXT NOT NULL, system INTEGER NOT NULL DEFAULT 0)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS user_roles (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, role_id INTEGER NOT NULL, assigned_by INTEGER, assigned_at TEXT NOT NULL, UNIQUE(user_id, role_id))`),
    db.prepare(`CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, excerpt TEXT NOT NULL, body TEXT NOT NULL, category TEXT NOT NULL, status TEXT NOT NULL, pinned INTEGER NOT NULL DEFAULT 0, author_id INTEGER, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, published_at TEXT)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE, user_id INTEGER NOT NULL, expires_at TEXT NOT NULL, created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT, actor_id INTEGER, action TEXT NOT NULL, target_type TEXT NOT NULL, target_id TEXT, detail TEXT NOT NULL, created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, channel TEXT NOT NULL, content TEXT NOT NULL, reported INTEGER NOT NULL DEFAULT 0, deleted INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL)`),
    db.prepare(`CREATE TABLE IF NOT EXISTS applications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, type TEXT NOT NULL, motivation TEXT NOT NULL, experience TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', staff_note TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)`),
    db.prepare(`CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(token_hash, expires_at)`), db.prepare(`CREATE INDEX IF NOT EXISTS idx_announcements_status_date ON announcements(status, published_at)`), db.prepare(`CREATE INDEX IF NOT EXISTS idx_user_roles_user ON user_roles(user_id)`), db.prepare(`CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at)`), db.prepare(`CREATE INDEX IF NOT EXISTS idx_chat_channel_created ON chat_messages(channel, created_at)`), db.prepare(`CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status, created_at)`),
  ]);
  for(const role of DEFAULT_ROLES){ await db.prepare(`INSERT INTO roles (slug,name,color,level,permissions,system) VALUES (?,?,?,?,?,1) ON CONFLICT(slug) DO UPDATE SET name=excluded.name,color=excluded.color,level=excluded.level,permissions=excluded.permissions`).bind(role.slug,role.name,role.color,role.level,JSON.stringify(role.permissions)).run(); }
  await db.prepare(`UPDATE announcements SET title='HighLife opent de stad',body=REPLACE(body,'Nexus Haven','HighLife Roleplay'),updated_at=? WHERE title='Seizoen 04 is geopend'`).bind(new Date().toISOString()).run();
  const count=await db.prepare(`SELECT COUNT(*) AS count FROM announcements`).first<{count:number}>();
  if(!count?.count){ const now=new Date().toISOString(); await db.batch([
    db.prepare(`INSERT INTO announcements (title,excerpt,body,category,status,pinned,created_at,updated_at,published_at) VALUES (?,?,?,?,?,1,?,?,?)`).bind('HighLife opent de stad','Een frisse start, nieuwe verhalen en een stad die opnieuw in beweging komt.','De deuren van HighLife Roleplay zijn geopend. Nieuwe ondernemingen, aangepaste overheidsdiensten en een vernieuwde economie wachten op je. Lees de regels, vorm je personage en schrijf het volgende hoofdstuk samen met de community.','Stadsnieuws','published',now,now,now),
    db.prepare(`INSERT INTO announcements (title,excerpt,body,category,status,pinned,created_at,updated_at,published_at) VALUES (?,?,?,?,?,0,?,?,?)`).bind('Communityavond: Midnight Run','Teams, checkpoints en één lange rit door de nacht.','Aanstaande vrijdag organiseren we Midnight Run. Schrijf je crew in, zorg voor een voertuig en meld je een kwartier voor de start bij de haven. Fair play en sterke roleplay staan voorop.','Event','published',now,now,now),
    db.prepare(`INSERT INTO announcements (title,excerpt,body,category,status,pinned,created_at,updated_at,published_at) VALUES (?,?,?,?,?,0,?,?,?)`).bind('Staffsollicitaties geopend','We zoeken rustige beslissers met aandacht voor spelers en verhalen.','Het staffteam breidt uit. We zoeken moderators die duidelijk communiceren, situaties objectief beoordelen en onze communitycultuur bewaken. Solliciteren kan vanuit je account.','Community','published',now,now,now),
  ]); }
  await db.prepare('PRAGMA optimize').run(); initialized=true;
}
export async function getUserWithPermissions(userId:number):Promise<SessionUser|null>{
  await ensureDb(); const db=database(); const user=await db.prepare(`SELECT id,discord_id AS discordId,username,display_name AS displayName,avatar FROM users WHERE id=?`).bind(userId).first<Omit<SessionUser,'roles'|'permissions'|'maxLevel'>>(); if(!user) return null;
  const rows=await db.prepare(`SELECT r.slug,r.permissions,r.level FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=?`).bind(userId).all<{slug:string;permissions:string;level:number}>();
  const permissions=new Set<string>(); let maxLevel=0; for(const row of rows.results){ try{ for(const p of JSON.parse(row.permissions)) permissions.add(p); }catch{} maxLevel=Math.max(maxLevel,row.level); }
  return {...user,roles:rows.results.map(r=>r.slug),permissions:[...permissions],maxLevel};
}
export async function writeAudit(actorId:number|null,action:string,targetType:string,targetId:string|null,detail:string){ await ensureDb(); await database().prepare(`INSERT INTO audit_logs (actor_id,action,target_type,target_id,detail,created_at) VALUES (?,?,?,?,?,?)`).bind(actorId,action,targetType,targetId,detail,new Date().toISOString()).run(); }
