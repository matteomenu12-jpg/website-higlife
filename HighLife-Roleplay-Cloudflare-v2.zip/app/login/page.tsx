import Link from 'next/link';
/* eslint-disable @next/next/no-img-element */
export default function Login(){return <main className="auth-page">
  <Link className="back-link" href="/">← Terug naar de stad</Link>
  <section className="auth-visual"><div className="auth-grid"/><span className="auth-index">HL/01</span><div><p className="eyebrow"><span/> BINNENKORT BESCHIKBAAR</p><h1>Één identiteit.<br/><em>Alle toegang.</em></h1><p>HighLife Identity wordt de veilige toegang tot je account, het forum, de communitychat en het staffplatform.</p></div></section>
  <section className="auth-panel"><div className="login-box"><img className="login-logo" src="/highlife-logo.jpg" alt="HighLife Roleplay"/><p className="kicker">HIGHLIFE IDENTITY</p><span className="soon-pill">BINNENKORT BESCHIKBAAR</span><h2>Jouw HighLife-account komt eraan</h2><p>We bouwen aan veilig inloggen met Discord, persoonlijke profielen en gekoppelde communityrollen. Deze functies worden na de eerste website-lancering geactiveerd.</p><Link className="discord-login" href="/announcements"><span>◈</span> Bekijk de laatste updates <b>→</b></Link><small>Forum, communitychat en het staffpanel volgen samen met HighLife Identity.</small></div></section>
</main>}
