import { env } from 'cloudflare:workers';
import { NextResponse } from 'next/server';
import { randomToken } from '@/lib/auth';

export async function GET(request:Request){
  const cfg=env as unknown as {DISCORD_CLIENT_ID?:string}; const origin=new URL(request.url).origin;
  if(!cfg.DISCORD_CLIENT_ID) return NextResponse.redirect(new URL('/login?error=not-configured',origin));
  const state=randomToken(18); const redirectUri=`${origin}/api/auth/discord/callback`;
  const url=new URL('https://discord.com/oauth2/authorize'); url.searchParams.set('client_id',cfg.DISCORD_CLIENT_ID); url.searchParams.set('response_type','code'); url.searchParams.set('redirect_uri',redirectUri); url.searchParams.set('scope','identify'); url.searchParams.set('state',state);
  const response=NextResponse.redirect(url); response.cookies.set('nh_oauth_state',state,{httpOnly:true,sameSite:'lax',secure:origin.startsWith('https:'),path:'/',maxAge:600}); return response;
}
