const links=[['Home','/#top'],['Nieuws','/announcements'],['Regels','/rules'],['Communitychat','/community'],['Serverstatus','/status'],['Solliciteren','/apply'],['Forum','/forum'],['Media','/media']];

export function MobileNav({active,accountHref='/login',accountLabel='Login met Discord'}:{active?:string;accountHref?:string;accountLabel?:string}){
  const activeHref:Record<string,string>={Home:'/#top',Nieuws:'/announcements',Regels:'/rules',Community:'/community',Status:'/status',Solliciteren:'/apply',Forum:'/forum',Media:'/media'};
  return <details className="mobile-menu">
    <summary aria-label="Navigatiemenu openen"><span/><span/><span/></summary>
    <div className="mobile-menu-panel">
      <p>HIGHLIFE NAVIGATIE</p>
      <nav aria-label="Mobiele navigatie">{links.map(([label,href],i)=><a className={activeHref[active||'']===href?'active':''} href={href} key={href}><small>{String(i+1).padStart(2,'0')}</small>{label}<b>→</b></a>)}</nav>
      <a className="mobile-account" href={accountHref}>{accountLabel}<span>↗</span></a>
    </div>
  </details>;
}
