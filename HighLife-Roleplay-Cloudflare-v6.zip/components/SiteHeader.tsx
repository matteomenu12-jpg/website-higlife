/* eslint-disable @next/next/no-img-element */
import type { SessionUser } from '@/lib/db';
import {getCurrentUser} from '@/lib/auth';
import {MobileNav} from './MobileNav';

export async function SiteHeader({active,user}:{active?:string;user?:SessionUser|null}){
  const currentUser=user===undefined?await getCurrentUser():user;
  const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Regels','/rules'],['Community','/community'],['Staffteam','/staff-team'],['Status','/status'],['Forum','/forum'],['Media','/media'],['Solliciteren','/apply']];
  const accountHref=currentUser?'/account':'/login';
  return <><div className="launch-strip"><b>HIGHLIFE IDENTITY</b><span>Discord-accounts en het communityforum zijn geopend.</span></div><header className="topbar inner-header">
    <a className="brand" href="/#top" aria-label="Terug naar het begin van HighLife Roleplay"><img className="brand-logo" src="/highlife-logo.jpg" alt="HighLife Roleplay-logo"/><span><b>HIGHLIFE</b><small>ROLEPLAY</small></span></a>
    <nav aria-label="Hoofdnavigatie">{links.map(([label,href])=><a className={active===label?'active':''} href={href} key={href}>{label}</a>)}</nav>
    {currentUser?<a className="account-pill" href={accountHref}>{currentUser.avatar?<img src={currentUser.avatar} alt=""/>:<span>{currentUser.displayName.slice(0,2).toUpperCase()}</span>}<b>{currentUser.displayName}</b></a>:<a className="discord-button" href="/login">Login met Discord <span>↗</span></a>}
    <MobileNav active={active} accountHref={accountHref} accountLabel={currentUser?`Account · ${currentUser.displayName}`:'Login met Discord'} accountAvatar={currentUser?.avatar}/>
  </header></>;
}
