const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Regels','/rules'],['Communitychat','/community'],['Staffteam','/staff-team'],['Serverstatus','/status'],['Solliciteren','/apply'],['Forum','/forum'],['Media','/media']];

export function MobileNav({active,accountHref='/login',accountLabel='Login met Discord',accountAvatar}:{active?:string;accountHref?:string;accountLabel?:string;accountAvatar?:string|null}){
  const activeHref:Record<string,string>={Home:'/#top',Nieuws:'/announcements',Blogs:'/blogs',Regels:'/rules',Community:'/community',Staffteam:'/staff-team',Status:'/status',Solliciteren:'/apply',Forum:'/forum',Media:'/media'};
  return <details className="mobile-menu">
    <summary aria-label="Navigatiemenu openen"><span/><span/><span/></summary>
    <div className="mobile-menu-panel">
      <p>HIGHLIFE NAVIGATIE</p>
      <nav aria-label="Mobiele navigatie">{links.map(([label,href],i)=><a className={activeHref[active||'']===href?'active':''} href={href} key={href}><small>{String(i+1).padStart(2,'0')}</small>{label}<b>→</b></a>)}</nav>
      <a className="mobile-account" href={accountHref}>{accountAvatar&&<img src={accountAvatar} alt=""/>}<b>{accountLabel}</b><span>↗</span></a>
    </div>
  </details>;
}
