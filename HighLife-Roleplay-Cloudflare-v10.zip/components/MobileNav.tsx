const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Regels','/rules'],['Communitychat','/community'],['Staffteam','/staff-team'],['Serverstatus','/status'],['Solliciteren','/apply'],['Forum','/forum'],['Media','/media']];

export function MobileNav({active,accountHref='/login',accountLabel='Login met Discord',accountAvatar,accountRole='Community',signedIn=false,isStaff=false}:{active?:string;accountHref?:string;accountLabel?:string;accountAvatar?:string|null;accountRole?:string;signedIn?:boolean;isStaff?:boolean}){
  const activeHref:Record<string,string>={Home:'/#top',Nieuws:'/announcements',Blogs:'/blogs',Regels:'/rules',Community:'/community',Staffteam:'/staff-team',Status:'/status',Solliciteren:'/apply',Forum:'/forum',Media:'/media'};
  return <details className="mobile-menu">
    <summary aria-label="Navigatiemenu openen"><span/><span/><span/></summary>
    <div className="mobile-menu-panel">
      <p>HIGHLIFE NAVIGATIE</p>
      <nav aria-label="Mobiele navigatie">{links.map(([label,href],i)=><a className={activeHref[active||'']===href?'active':''} href={href} key={href}><small>{String(i+1).padStart(2,'0')}</small>{label}<b>→</b></a>)}</nav>
      <div className="mobile-account-card">{accountAvatar&&<img src={accountAvatar} alt=""/>}<p><b>{accountLabel}</b>{signedIn&&<small>{accountRole}</small>}</p>{!signedIn&&<a href={accountHref}>Login ↗</a>}</div>
      {signedIn&&<div className="mobile-account-links"><a href="/account">Accountinstellingen <b>→</b></a><a href="/account/activity">Mijn activiteit <b>→</b></a>{isStaff&&<a className="staff-entry" href="/staff">Staffpanel <b>→</b></a>}</div>}
    </div>
  </details>;
}
