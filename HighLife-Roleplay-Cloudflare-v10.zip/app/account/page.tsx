import {redirect} from 'next/navigation';
import {getCurrentUser} from '@/lib/auth';
import {database,ensureDb} from '@/lib/db';
import {isHighLifeOwner} from '@/lib/owner';
import {SiteHeader} from '@/components/SiteHeader';

export const dynamic='force-dynamic';

export default async function Account(){
  const user=await getCurrentUser();if(!user)redirect('/login');
  await ensureDb();const db=database();
  const topics=await db.prepare(`SELECT COUNT(*) AS count FROM forum_topics WHERE user_id=?`).bind(user.id).first<{count:number}>();
  const replies=await db.prepare(`SELECT COUNT(*) AS count FROM forum_replies WHERE user_id=?`).bind(user.id).first<{count:number}>();
  const contributions=(topics?.count||0)+(replies?.count||0);
  return <main className="inner-page"><SiteHeader active="" user={user}/><section className="account-shell"><aside className="account-side">
    {user.avatar?<img className="profile-avatar profile-image" src={user.avatar} alt=""/>:<div className="profile-avatar">{user.displayName.slice(0,2).toUpperCase()}</div>}
    <h1>{user.displayName}</h1><p>@{user.username}</p><div>{user.roles.length?user.roles.map(r=><span key={r}>{r}</span>):<span>community</span>}</div>
    <nav><a className="active" href="#overview">Overzicht</a><a href="#identity">Discord-identiteit</a><a href="/account/activity">Mijn activiteit</a><a href="/forum">Mijn forum</a>{isHighLifeOwner(user)&&<a href="/staff">Eigenaarspanel →</a>}</nav>
  </aside><section className="account-main" id="overview"><p className="kicker">ACCOUNT OVERVIEW</p><h2>Welkom terug in HighLife.</h2><div className="metric-cards"><article><span>FORUMTOPICS</span><strong>{topics?.count||0}</strong><p>Topics gestart</p></article><article><span>FORUMBIJDRAGEN</span><strong>{contributions}</strong><p>Topics en reacties</p></article><article><span>ACCOUNTSTATUS</span><strong className="status-ok">ACTIEF</strong><p>Discord geverifieerd</p></article></div><article id="identity" className="identity-card"><div><p className="kicker">VERBONDEN IDENTITEIT</p><h3>Discord</h3><p>{user.displayName} · @{user.username}</p></div><span>GEKOPPELD</span></article><form action="/api/auth/logout" method="post"><button className="logout-button">Uitloggen</button></form></section></section></main>;
}
