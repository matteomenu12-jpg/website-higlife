import type { Metadata } from 'next';
import { headers } from 'next/headers';
import { Rajdhani, Manrope } from 'next/font/google';
import './globals.css';
import './highlife.css';
import './v12.css';
import './v13.css';
import {MotionObserver} from '@/components/MotionObserver';
import {GlobalControls} from '@/components/GlobalControls';

const display = Rajdhani({ variable: '--font-display', subsets: ['latin'], weight: ['500','600','700'] });
const body = Manrope({ variable: '--font-body', subsets: ['latin'] });

export async function generateMetadata():Promise<Metadata>{
  const host=(await headers()).get('host')??'localhost:3000';
  const trusted=/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host)||host.endsWith('.chatgpt.site');
  const origin=trusted?`${host.startsWith('localhost')||host.startsWith('127.')?'http':'https'}://${host}`:'https://chatgpt.com';
  return { metadataBase:new URL(origin), title:'HighLife Roleplay', description:'Een Nederlandse FiveM roleplaycommunity aan de tropische skyline.', applicationName:'HighLife RP', themeColor:'#17101f', icons:{icon:[{url:'/icon-192.png',sizes:'192x192',type:'image/png'},{url:'/icon-512.png',sizes:'512x512',type:'image/png'}],shortcut:'/icon-192.png',apple:[{url:'/apple-touch-icon.png',sizes:'180x180',type:'image/png'}]}, appleWebApp:{capable:true,statusBarStyle:'black-translucent',title:'HighLife RP'}, manifest:'/manifest.webmanifest', openGraph:{title:'HighLife Roleplay',description:'Jouw verhaal. Jouw HighLife.',images:[{url:'/highlife-v12-banner.png',width:1672,height:941,alt:'HighLife Roleplay aan een tropische skyline bij zonsondergang'}]}, twitter:{card:'summary_large_image',title:'HighLife Roleplay',description:'Jouw verhaal. Jouw HighLife.',images:['/highlife-v12-banner.png']} };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="nl"><body className={`${display.variable} ${body.variable}`}><MotionObserver/><GlobalControls/>{children}</body></html>;
}
