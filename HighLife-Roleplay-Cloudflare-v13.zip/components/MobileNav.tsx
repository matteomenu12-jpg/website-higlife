const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Regels','/rules'],['Communitychat','/community'],['Staffteam','/staff-team'],['Serverstatus','/status'],['Solliciteren','/apply'],['Forum','/forum'],['Media','/media']];

export function MobileNav({active,accountHref='/login',accountLabel='Login met Discord',accountAvatar,accountRole='Community',signedIn=false,isStaff=false}:{active?:string;accountHref?:string;accountLabel?:string;accountAvatar?:string|null;accountRole?:string;signedIn?:boolean;isStaff?:boolean}){
  const activeHref:Record<string,string>={Home:'/#top',Nieuws:'/announcements',Blogs:'/blogs',Regels:'/rules',Community:'/community',Staffteam:'/staff-team',Status:'/status',Solliciteren:'/apply',Forum:'/forum',Media:'/media'};
  return <details className="mobile-menu">
    <summary aria-label="Navigatiemenu openen"><span/><span/><span/></summary>
    <div className="mobile-menu-panel">
      <header><div><b>Menu</b><small>HighLife Roleplay</small></div><span>V13</span></header>
      <div className="mobile-account-card">{accountAvatar?<img src={accountAvatar} alt=""/>:<span className="mobile-account-fallback">{signedIn?accountLabel.slice(0,2).toUpperCase():'HL'}</span>}<p><b>{accountLabel}</b><small>{signedIn?accountRole:'Discord-account'}</small></p><a href={accountHref}>{signedIn?'Open':'Login'} →</a></div>
      <p className="mobile-section-label">PAGINA&apos;S</p>
      <nav aria-label="Mobiele navigatie">{links.map(([label,href])=><a className={activeHref[active||'']===href?'active':''} href={href} key={href}>{label}<b>→</b></a>)}</nav>
      {signedIn&&<div className="mobile-account-links"><a href="/account">Accountinstellingen <b>→</b></a><a href="/account/activity">Mijn activiteit <b>→</b></a><a href="/tickets">Tickets <b>→</b></a><a href="/web-history">Web Geschiedenis <b>→</b></a>{isStaff&&<a className="staff-entry" href="/staff">Staffpanel <b>→</b></a>}</div>}
    </div>
  </details>;
}
