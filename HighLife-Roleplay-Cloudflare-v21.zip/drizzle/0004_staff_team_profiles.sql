ALTER TABLE `staff_team` ADD `group_name` text DEFAULT 'Community Staff' NOT NULL;
--> statement-breakpoint
ALTER TABLE `staff_team` ADD `discord_url` text DEFAULT '' NOT NULL;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `idx_staff_team_group_order` ON `staff_team` (`group_name`,`sort_order`,`id`);
