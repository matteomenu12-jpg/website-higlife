import {NextResponse} from 'next/server';
import {sameOrigin,userFromRequest} from '@/lib/auth';
import {database,ensureDb,writeAudit} from '@/lib/db';
import {isHighLifeOwner} from '@/lib/owner';

export async function POST(request:Request){
  if(!sameOrigin(request))return NextResponse.json({error:'Ongeldige aanvraag'},{status:403});
  const user=await userFromRequest(request);
  if(!isHighLifeOwner(user))return NextResponse.json({error:'Geen toegang'},{status:403});
  await ensureDb();
  const db=database();
  const input=await request.json() as {action?:string;id?:number;name?:string;rank?:string;groupName?:string;discordUrl?:string;direction?:'up'|'down'};
  const profile=(value:string|undefined)=>{const url=String(value||'').trim();if(!url)return '';try{const parsed=new URL(url);if(parsed.protocol!=='https:'||!['discord.com','www.discord.com','discordapp.com','www.discordapp.com'].includes(parsed.hostname)||!/^\/users\/\d{15,22}\/?$/.test(parsed.pathname))return null;return `https://discord.com${parsed.pathname.replace(/\/$/,'')}`}catch{return null}};
  if(input.action==='create'){
    const name=String(input.name||'').trim();
    const rank=String(input.rank||'').trim();
    const groupName=String(input.groupName||'Community Staff').trim();const discordUrl=profile(input.discordUrl);
    if(name.length<2||name.length>80||rank.length<2||rank.length>80||groupName.length<2||groupName.length>60)return NextResponse.json({error:'Vul een geldige naam, rang en groep in.'},{status:400});
    if(discordUrl===null)return NextResponse.json({error:'Gebruik een geldige Discord-profiel-link, bijvoorbeeld https://discord.com/users/123...'},{status:400});
    const order=await db.prepare(`SELECT COALESCE(MAX(sort_order),-1)+1 AS nextOrder FROM staff_team`).first<{nextOrder:number}>();
    const now=new Date().toISOString();
    const result=await db.prepare(`INSERT INTO staff_team (name,rank,group_name,discord_url,sort_order,created_at,updated_at) VALUES (?,?,?,?,?,?,?)`).bind(name,rank,groupName,discordUrl,order?.nextOrder??0,now,now).run();
    await writeAudit(user.id,'staff_team.create','staff_team',String(result.meta.last_row_id),`${name} toegevoegd als ${rank}`);
    return NextResponse.json({ok:true});
  }
  if(input.action==='edit'&&Number.isInteger(input.id)){
    const name=String(input.name||'').trim();const rank=String(input.rank||'').trim();const groupName=String(input.groupName||'Community Staff').trim();const discordUrl=profile(input.discordUrl);
    if(name.length<2||name.length>80||rank.length<2||rank.length>80||groupName.length<2||groupName.length>60)return NextResponse.json({error:'Vul een geldige naam, rang en groep in.'},{status:400});
    if(discordUrl===null)return NextResponse.json({error:'Gebruik een geldige Discord-profiel-link.'},{status:400});
    const result=await db.prepare(`UPDATE staff_team SET name=?,rank=?,group_name=?,discord_url=?,updated_at=? WHERE id=?`).bind(name,rank,groupName,discordUrl,new Date().toISOString(),input.id).run();
    if(!result.meta.changes)return NextResponse.json({error:'Stafflid niet gevonden.'},{status:404});
    await writeAudit(user.id,'staff_team.edit','staff_team',String(input.id),`${name} aangepast naar ${rank}`);
    return NextResponse.json({ok:true});
  }
  if(input.action==='move'&&Number.isInteger(input.id)&&(input.direction==='up'||input.direction==='down')){
    const member=await db.prepare(`SELECT id,sort_order AS sortOrder FROM staff_team WHERE id=?`).bind(input.id).first<{id:number;sortOrder:number}>();
    if(!member)return NextResponse.json({error:'Stafflid niet gevonden.'},{status:404});
    const sign=input.direction==='up'?'<':'>';const order=input.direction==='up'?'DESC':'ASC';
    const neighbour=await db.prepare(`SELECT id,sort_order AS sortOrder FROM staff_team WHERE sort_order ${sign} ? OR (sort_order=? AND id ${sign} ?) ORDER BY sort_order ${order},id ${order} LIMIT 1`).bind(member.sortOrder,member.sortOrder,member.id).first<{id:number;sortOrder:number}>();
    if(!neighbour)return NextResponse.json({ok:true});
    const marker=Math.max(member.sortOrder,neighbour.sortOrder)+1000000;
    await db.batch([db.prepare(`UPDATE staff_team SET sort_order=? WHERE id=?`).bind(marker,member.id),db.prepare(`UPDATE staff_team SET sort_order=? WHERE id=?`).bind(member.sortOrder,neighbour.id),db.prepare(`UPDATE staff_team SET sort_order=?,updated_at=? WHERE id=?`).bind(neighbour.sortOrder,new Date().toISOString(),member.id)]);
    await writeAudit(user.id,'staff_team.move','staff_team',String(input.id),`Stafflid ${input.direction==='up'?'omhoog':'omlaag'} verplaatst`);
    return NextResponse.json({ok:true});
  }
  if(input.action==='delete'&&Number.isInteger(input.id)){
    const member=await db.prepare(`SELECT name,rank FROM staff_team WHERE id=?`).bind(input.id).first<{name:string;rank:string}>();
    if(!member)return NextResponse.json({error:'Stafflid niet gevonden.'},{status:404});
    await db.prepare(`DELETE FROM staff_team WHERE id=?`).bind(input.id).run();
    await writeAudit(user.id,'staff_team.delete','staff_team',String(input.id),`${member.name} (${member.rank}) verwijderd`);
    return NextResponse.json({ok:true});
  }
  return NextResponse.json({error:'Ongeldige actie.'},{status:400});
}
