/* eslint-disable @next/next/no-img-element */
import type { SessionUser } from '@/lib/db';
import {MobileNav} from './MobileNav';

export function SiteHeader({active,user}:{active?:string;user?:SessionUser|null}){
  const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Regels','/rules'],['Community','/community'],['Status','/status'],['Forum','/forum'],['Media','/media'],['Solliciteren','/apply']];
  const accountHref=user?(user.permissions.includes('*')||user.permissions.includes('staff.access')?'/staff':'/account'):'/login';
  return <><div className="launch-strip"><b>HIGHLIFE IDENTITY</b><span>Discord-accounts en het communityforum zijn geopend.</span></div><header className="topbar inner-header">
    <a className="brand" href="/#top" aria-label="Terug naar het begin van HighLife Roleplay"><img className="brand-logo" src="/highlife-logo.jpg" alt="HighLife Roleplay-logo"/><span><b>HIGHLIFE</b><small>ROLEPLAY</small></span></a>
    <nav aria-label="Hoofdnavigatie">{links.map(([label,href])=><a className={active===label?'active':''} href={href} key={href}>{label}</a>)}</nav>
    {user?<a className="account-pill" href={accountHref}><span>{user.displayName.slice(0,2).toUpperCase()}</span>{user.displayName}</a>:<a className="discord-button" href="/login">Login met Discord <span>↗</span></a>}
    <MobileNav active={active} accountHref={accountHref} accountLabel={user?`Account · ${user.displayName}`:'Login met Discord'}/>
  </header></>;
}
