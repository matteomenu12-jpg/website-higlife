import Link from 'next/link';
/* eslint-disable @next/next/no-img-element */
import type { SessionUser } from '@/lib/db';
import {MobileNav} from './MobileNav';

export function SiteHeader({active,user}:{active?:string;user?:SessionUser|null}){
  const links=[['Home','/'],['Nieuws','/announcements'],['Regels','/rules'],['Community','/community'],['Status','/status'],['Solliciteren','/apply']];
  const accountHref=user?(user.permissions.includes('*')||user.permissions.includes('staff.access')?'/staff':'/account'):'/login';
  return <><div className="launch-strip"><b>HIGHLIFE UPDATE</b><span>Accounts, forum en communityfuncties komen binnenkort.</span></div><header className="topbar inner-header">
    <Link className="brand" href="/"><img className="brand-logo" src="/highlife-logo.jpg" alt=""/><span><b>HIGHLIFE</b><small>ROLEPLAY</small></span></Link>
    <nav aria-label="Hoofdnavigatie">{links.map(([label,href])=><Link className={active===label?'active':''} href={href} key={href}>{label}</Link>)}</nav>
    {user?<Link className="account-pill" href={accountHref}><span>{user.displayName.slice(0,2).toUpperCase()}</span>{user.displayName}</Link>:<Link className="discord-button" href="/login">Account binnenkort <span>↗</span></Link>}
    <MobileNav active={active} accountHref={accountHref} accountLabel={user?`Account · ${user.displayName}`:'Account binnenkort'}/>
  </header></>;
}
