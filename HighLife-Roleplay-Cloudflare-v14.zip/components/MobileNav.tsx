'use client';

import {useState} from 'react';

const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Regels','/rules'],['Communitychat','/community'],['Staffteam','/staff-team'],['Serverstatus','/status'],['Solliciteren','/apply'],['Forum','/forum'],['Media','/media']];

export function MobileNav({active,accountHref='/login',accountLabel='Login met Discord',accountAvatar,accountRole='Community',signedIn=false,isStaff=false}:{active?:string;accountHref?:string;accountLabel?:string;accountAvatar?:string|null;accountRole?:string;signedIn?:boolean;isStaff?:boolean}){
  const [open,setOpen]=useState(false);
  const activeHref:Record<string,string>={Home:'/#top',Nieuws:'/announcements',Blogs:'/blogs',Regels:'/rules',Community:'/community',Staffteam:'/staff-team',Status:'/status',Solliciteren:'/apply',Forum:'/forum',Media:'/media'};
  const close=()=>setOpen(false);
  return <div className={`mobile-menu${open?' is-open':''}`}>
    <button type="button" className="mobile-menu-trigger" aria-label={open?'Navigatiemenu sluiten':'Navigatiemenu openen'} aria-expanded={open} onClick={()=>setOpen(!open)}><span/><span/><span/></button>
    {open&&<div className="mobile-menu-panel">
      <header><div><b>Menu</b><small>HighLife Roleplay</small></div><span>V13</span></header>
      <div className="mobile-account-card">{accountAvatar?<img src={accountAvatar} alt=""/>:<span className="mobile-account-fallback">{signedIn?accountLabel.slice(0,2).toUpperCase():'HL'}</span>}<p><b>{accountLabel}</b><small>{signedIn?accountRole:'Discord-account'}</small></p><a href={accountHref} onClick={close}>{signedIn?'Open':'Login'} →</a></div>
      <p className="mobile-section-label">PAGINA&apos;S</p>
      <nav aria-label="Mobiele navigatie">{links.map(([label,href])=><a className={activeHref[active||'']===href?'active':''} href={href} onClick={close} key={href}>{label}<b>→</b></a>)}</nav>
      {signedIn&&<div className="mobile-account-links"><a href="/account" onClick={close}>Accountinstellingen <b>→</b></a><a href="/account/activity" onClick={close}>Mijn activiteit <b>→</b></a><a href="/tickets" onClick={close}>Tickets <b>→</b></a><a href="/web-history" onClick={close}>Web Geschiedenis <b>→</b></a>{isStaff&&<a className="staff-entry" href="/staff" onClick={close}>Staffpanel <b>→</b></a>}</div>}
    </div>}
  </div>;
}
