'use client';

import {useEffect,useState} from 'react';
import {createPortal} from 'react-dom';

const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Forum','/forum'],['Communitychat','/community'],['Regels','/rules'],['Media','/media'],['Staffteam','/staff-team'],['Serverstatus','/status'],['Solliciteren','/apply'],['Web Geschiedenis','/web-history']];

export function MobileNav({active,accountHref='/login',accountLabel='Login met Discord',accountAvatar,accountRole='Community',signedIn=false,isStaff=false}:{active?:string;accountHref?:string;accountLabel?:string;accountAvatar?:string|null;accountRole?:string;signedIn?:boolean;isStaff?:boolean}){
  const [open,setOpen]=useState(false);
  const [mounted,setMounted]=useState(false);
  const activeHref:Record<string,string>={Home:'/#top',Nieuws:'/announcements',Blogs:'/blogs',Regels:'/rules',Community:'/community',Staffteam:'/staff-team',Status:'/status',Solliciteren:'/apply',Forum:'/forum',Media:'/media'};
  const close=()=>setOpen(false);

  useEffect(()=>setMounted(true),[]);
  useEffect(()=>{
    if(!open)return;
    const previousOverflow=document.body.style.overflow;
    const onKeyDown=(event:KeyboardEvent)=>{if(event.key==='Escape')close();};
    document.body.style.overflow='hidden';
    window.addEventListener('keydown',onKeyDown);
    return ()=>{document.body.style.overflow=previousOverflow;window.removeEventListener('keydown',onKeyDown);};
  },[open]);

  const drawer=mounted&&open?createPortal(
    <div className="hl-mobile-overlay" onClick={close}>
      <aside className="hl-mobile-drawer" role="dialog" aria-modal="true" aria-label="Navigatiemenu" onClick={(event)=>event.stopPropagation()}>
        <header className="hl-mobile-drawer-head">
          <a className="hl-mobile-drawer-brand" href="/#top" onClick={close}><img src="/highlife_offi_logo.gif" alt=""/><span><b>HighLife</b><small>Roleplay</small></span></a>
          <button type="button" onClick={close} aria-label="Navigatiemenu sluiten"><span/><span/></button>
        </header>
        <a className="hl-mobile-account" href={accountHref} onClick={close}>
          {accountAvatar?<img src={accountAvatar} alt=""/>:<span className="hl-mobile-account-fallback">{signedIn?accountLabel.slice(0,2).toUpperCase():'HL'}</span>}
          <span><b>{accountLabel}</b><small>{signedIn?accountRole:'Login met je Discord-account'}</small></span><strong>→</strong>
        </a>
        <p className="hl-mobile-label">PAGINA&apos;S</p>
        <nav className="hl-mobile-links" aria-label="Mobiele navigatie">{links.map(([label,href])=><a className={activeHref[active||'']===href?'active':''} href={href} onClick={close} key={href}><span>{label}</span><b>→</b></a>)}</nav>
        {signedIn&&<><p className="hl-mobile-label">MIJN HIGHLIFE</p><nav className="hl-mobile-user-links" aria-label="Accountnavigatie"><a href="/account" onClick={close}>Accountinstellingen <b>→</b></a><a href="/account/activity" onClick={close}>Mijn activiteit <b>→</b></a><a href="/tickets" onClick={close}>Tickets <b>→</b></a>{isStaff&&<a className="staff-entry" href="/staff" onClick={close}>Staffpanel <b>→</b></a>}</nav></>}
      </aside>
    </div>,document.body):null;

  return <><div className={`hl-mobile-nav${open?' is-open':''}`}><button type="button" className="hl-mobile-trigger" aria-label={open?'Navigatiemenu sluiten':'Navigatiemenu openen'} aria-expanded={open} onClick={()=>setOpen(value=>!value)}><span/><span/><span/></button></div>{drawer}</>;
}
