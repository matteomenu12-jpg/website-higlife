/* eslint-disable @next/next/no-img-element */
import type { SessionUser } from '@/lib/db';
import {getCurrentUser} from '@/lib/auth';
import {MobileNav} from './MobileNav';

export async function SiteHeader({active,user}:{active?:string;user?:SessionUser|null}){
  const currentUser=user===undefined?await getCurrentUser():user;
  const roleNames:Record<string,string>={owner:'Eigenaar',management:'Management',admin:'Administrator',administrator:'Administrator',moderator:'Moderator',communications:'Communicatie',support:'Support',developer:'Developer'};
  const role=currentUser?(roleNames[currentUser.roles[0]]||currentUser.roles[0]||'Community'):'Community';
  const isStaff=!!currentUser&&(currentUser.permissions.includes('*')||currentUser.permissions.includes('staff.access'));
  const primaryLinks=[['Home','/#top'],['Nieuws','/announcements'],['Forum','/forum'],['Community','/community'],['Regels','/rules'],['Media','/media']];
  const moreLinks=[['Blogs','/blogs'],['Staffteam','/staff-team'],['Serverstatus','/status'],['Solliciteren','/apply'],['Web Geschiedenis','/web-history']];
  const accountHref=currentUser?'/account':'/login';
  return <><div className="launch-strip"><b>HIGHLIFE V17</b><span>Nieuwe Liquid Glass-look en verbeterd delen zijn live.</span><a href="/web-history">Bekijk update →</a></div><header className="topbar inner-header">
    <a className="brand" href="/#top" aria-label="Terug naar het begin van HighLife Roleplay"><img className="brand-logo" src="/highlife-v12-logo.png" alt="HighLife Roleplay-logo"/><span><b>HIGHLIFE</b><small>ROLEPLAY</small></span></a>
    <nav className="desktop-nav" aria-label="Hoofdnavigatie">{primaryLinks.map(([label,href])=><a className={active===label?'active':''} href={href} key={href}>{label}</a>)}<details className="more-nav"><summary>Meer <span>⌄</span></summary><div>{moreLinks.map(([label,href])=><a className={active===label?'active':''} href={href} key={href}>{label}<span>↗</span></a>)}</div></details></nav>
    <div className="header-actions">{currentUser?<details className="account-dropdown"><summary>{currentUser.avatar?<img src={currentUser.avatar} alt=""/>:<span>{currentUser.displayName.slice(0,2).toUpperCase()}</span>}<span className="account-identity"><b>{currentUser.displayName}</b><small>{role}</small></span><i>⌄</i></summary><div><p><b>{currentUser.displayName}</b><small>@{currentUser.username} · {role}</small></p><a href="/account"><span>◉</span>Accountinstellingen<b>→</b></a><a href="/account/activity"><span>✦</span>Mijn activiteit<b>→</b></a><a href="/tickets"><span>◎</span>Tickets<b>→</b></a><a href="/web-history"><span>↻</span>Web Geschiedenis<b>→</b></a>{isStaff&&<a className="staff-entry" href="/staff"><span>◆</span>Staffpanel<b>→</b></a>}<form action="/api/auth/logout" method="post"><button>Uitloggen</button></form></div></details>:<a className="discord-button" href="/login">Login <span>↗</span></a>}{currentUser&&<a className="mobile-profile-shortcut" href="/account" aria-label={`Account van ${currentUser.displayName}`}>{currentUser.avatar?<img src={currentUser.avatar} alt=""/>:<span>{currentUser.displayName.slice(0,2).toUpperCase()}</span>}</a>}
    <MobileNav active={active} accountHref={accountHref} accountLabel={currentUser?.displayName||'Login met Discord'} accountAvatar={currentUser?.avatar} accountRole={role} signedIn={!!currentUser} isStaff={isStaff}/>
    </div></header></>;
}
