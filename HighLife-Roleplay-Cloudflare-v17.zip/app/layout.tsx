import type { Metadata } from 'next';
import { headers } from 'next/headers';
import { Rajdhani, Manrope } from 'next/font/google';
import './globals.css';
import './highlife.css';
import './v12.css';
import './v13.css';
import './v17.css';
import {MotionObserver} from '@/components/MotionObserver';
import {GlobalControls} from '@/components/GlobalControls';

const display = Rajdhani({ variable: '--font-display', subsets: ['latin'], weight: ['500','600','700'] });
const body = Manrope({ variable: '--font-body', subsets: ['latin'] });

export async function generateMetadata():Promise<Metadata>{
  const host=(await headers()).get('host')??'localhost:3000';
  const local=/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host);
  const trusted=local||host==='website-higlife.highlife.workers.dev'||host.endsWith('.chatgpt.site');
  const origin=trusted?`${local?'http':'https'}://${host}`:'https://website-higlife.highlife.workers.dev';
  const preview={url:'/og-v17.jpg',width:1200,height:630,alt:'HighLife Roleplay — Jouw verhaal. Jouw HighLife.'};
  return { metadataBase:new URL(origin), title:'HighLife Roleplay', description:'Een Nederlandse FiveM roleplaycommunity aan de tropische skyline.', applicationName:'HighLife RP', themeColor:'#25142f', icons:{icon:[{url:'/icon-192.png',sizes:'192x192',type:'image/png'},{url:'/icon-512.png',sizes:'512x512',type:'image/png'}],shortcut:'/icon-192.png',apple:[{url:'/apple-touch-icon.png',sizes:'180x180',type:'image/png'}]}, appleWebApp:{capable:true,statusBarStyle:'black-translucent',title:'HighLife RP'}, manifest:'/manifest.webmanifest', openGraph:{type:'website',locale:'nl_BE',url:'/',siteName:'HighLife Roleplay',title:'HighLife Roleplay',description:'Jouw verhaal. Jouw HighLife.',images:[preview]}, twitter:{card:'summary_large_image',title:'HighLife Roleplay',description:'Jouw verhaal. Jouw HighLife.',images:['/og-v17.jpg']} };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="nl"><body className={`${display.variable} ${body.variable}`}><MotionObserver/><GlobalControls/>{children}</body></html>;
}
