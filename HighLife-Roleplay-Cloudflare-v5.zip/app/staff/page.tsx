import { redirect } from 'next/navigation';import { getCurrentUser } from '@/lib/auth';import { isHighLifeOwner } from '@/lib/owner';import StaffPanel from '@/components/StaffPanel';
export const dynamic='force-dynamic';
export default async function Staff(){const user=await getCurrentUser();if(!user)redirect('/login');if(!isHighLifeOwner(user))redirect('/account');return <StaffPanel/>}
