import {NextResponse} from 'next/server';
import {userFromRequest} from '@/lib/auth';
import {database,ensureDb,writeAudit} from '@/lib/db';
import {isHighLifeOwner} from '@/lib/owner';

export async function POST(request:Request){
  const user=await userFromRequest(request);
  if(!isHighLifeOwner(user))return NextResponse.json({error:'Geen toegang'},{status:403});
  await ensureDb();
  const db=database();
  const input=await request.json() as {action?:string;id?:number;name?:string;rank?:string};
  if(input.action==='create'){
    const name=String(input.name||'').trim();
    const rank=String(input.rank||'').trim();
    if(name.length<2||name.length>80||rank.length<2||rank.length>80)return NextResponse.json({error:'Vul een geldige naam en rang in.'},{status:400});
    const order=await db.prepare(`SELECT COALESCE(MAX(sort_order),-1)+1 AS nextOrder FROM staff_team`).first<{nextOrder:number}>();
    const now=new Date().toISOString();
    const result=await db.prepare(`INSERT INTO staff_team (name,rank,sort_order,created_at,updated_at) VALUES (?,?,?,?,?)`).bind(name,rank,order?.nextOrder??0,now,now).run();
    await writeAudit(user.id,'staff_team.create','staff_team',String(result.meta.last_row_id),`${name} toegevoegd als ${rank}`);
    return NextResponse.json({ok:true});
  }
  if(input.action==='delete'&&Number.isInteger(input.id)){
    const member=await db.prepare(`SELECT name,rank FROM staff_team WHERE id=?`).bind(input.id).first<{name:string;rank:string}>();
    if(!member)return NextResponse.json({error:'Stafflid niet gevonden.'},{status:404});
    await db.prepare(`DELETE FROM staff_team WHERE id=?`).bind(input.id).run();
    await writeAudit(user.id,'staff_team.delete','staff_team',String(input.id),`${member.name} (${member.rank}) verwijderd`);
    return NextResponse.json({ok:true});
  }
  return NextResponse.json({error:'Ongeldige actie.'},{status:400});
}
