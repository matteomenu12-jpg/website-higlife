# HighLife Roleplay Website

Publieke launchversie van de officiële HighLife Roleplay-website.

## Cloudflare deployment

- Build command: `npm run build`
- Deploy command: `npx wrangler deploy`
- Root directory: `/`
- Node.js version: `22`

Cloudflare gebruikt `wrangler.jsonc` om de gebouwde Worker en de statische bestanden te publiceren. De website krijgt automatisch een gratis `workers.dev`-adres.

## Later activeren

Accounts, Discord-login, forum, communitychat, sollicitaties en het staffpanel staan in de codebase maar worden pas geactiveerd nadat de benodigde Cloudflare D1-database en geheime omgevingsvariabelen zijn gekoppeld.

Plaats nooit Discord-secrets, tokens of andere wachtwoorden in deze publieke repository.
