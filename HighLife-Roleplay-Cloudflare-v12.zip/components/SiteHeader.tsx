/* eslint-disable @next/next/no-img-element */
import type { SessionUser } from '@/lib/db';
import {getCurrentUser} from '@/lib/auth';
import {MobileNav} from './MobileNav';

export async function SiteHeader({active,user}:{active?:string;user?:SessionUser|null}){
  const currentUser=user===undefined?await getCurrentUser():user;
  const roleNames:Record<string,string>={owner:'Eigenaar',management:'Management',admin:'Administrator',administrator:'Administrator',moderator:'Moderator',communications:'Communicatie',support:'Support',developer:'Developer'};
  const role=currentUser?(roleNames[currentUser.roles[0]]||currentUser.roles[0]||'Community'):'Community';
  const isStaff=!!currentUser&&(currentUser.permissions.includes('*')||currentUser.permissions.includes('staff.access'));
  const links=[['Home','/#top'],['Nieuws','/announcements'],['Blogs','/blogs'],['Regels','/rules'],['Community','/community'],['Staffteam','/staff-team'],['Status','/status'],['Forum','/forum'],['Media','/media'],['Solliciteren','/apply']];
  const accountHref=currentUser?'/account':'/login';
  return <><div className="launch-strip"><b>HIGHLIFE IDENTITY</b><span>Discord-accounts en het communityforum zijn geopend.</span></div><header className="topbar inner-header">
    <a className="brand" href="/#top" aria-label="Terug naar het begin van HighLife Roleplay"><img className="brand-logo" src="/highlife-v12-logo.png" alt="Bewegend HighLife Roleplay-logo"/><span><b>HIGHLIFE</b><small>ROLEPLAY</small></span></a>
    <nav aria-label="Hoofdnavigatie">{links.map(([label,href])=><a className={active===label?'active':''} href={href} key={href}>{label}</a>)}</nav>
    {currentUser?<details className="account-dropdown"><summary>{currentUser.avatar?<img src={currentUser.avatar} alt=""/>:<span>{currentUser.displayName.slice(0,2).toUpperCase()}</span>}<span className="account-identity"><b>{currentUser.displayName}</b><small>{role}</small></span><i>⌄</i></summary><div><p><b>{currentUser.displayName}</b><small>@{currentUser.username} · {role}</small></p><a href="/account"><span>◉</span>Accountinstellingen<b>→</b></a><a href="/account/activity"><span>✦</span>Mijn activiteit<b>→</b></a><a href="/tickets"><span>◎</span>Tickets<b>→</b></a><a href="/web-history"><span>↻</span>Web Geschiedenis<b>→</b></a>{isStaff&&<a className="staff-entry" href="/staff"><span>◆</span>Staffpanel<b>→</b></a>}<form action="/api/auth/logout" method="post"><button>Uitloggen</button></form></div></details>:<a className="discord-button" href="/login">Login met Discord <span>↗</span></a>}
    <MobileNav active={active} accountHref={accountHref} accountLabel={currentUser?.displayName||'Login met Discord'} accountAvatar={currentUser?.avatar} accountRole={role} signedIn={!!currentUser} isStaff={isStaff}/>
  </header></>;
}
