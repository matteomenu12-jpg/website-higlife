import { env } from 'cloudflare:workers';
import { NextResponse } from 'next/server';

export const dynamic='force-dynamic';
export async function GET(){
  const cfg=env as unknown as {FIVEM_SERVER_URL?:string;FIVEM_CONNECT_URL?:string};
  if(!cfg.FIVEM_SERVER_URL)return NextResponse.json({configured:false,online:false,players:0,maxPlayers:0,serverName:'HighLife Roleplay',connectUrl:cfg.FIVEM_CONNECT_URL||'#',lastUpdated:new Date().toISOString()});
  try{
    const base=cfg.FIVEM_SERVER_URL.replace(/\/$/,'');
    const [dynamic,info]=await Promise.all([fetch(`${base}/dynamic.json`,{signal:AbortSignal.timeout(5000)}),fetch(`${base}/info.json`,{signal:AbortSignal.timeout(5000)})]);
    if(!dynamic.ok||!info.ok)throw new Error('FiveM endpoint reageert niet');
    const d=await dynamic.json() as {clients?:number;sv_maxclients?:number;hostname?:string};const i=await info.json() as {vars?:Record<string,string>};
    return NextResponse.json({configured:true,online:true,players:Number(d.clients||0),maxPlayers:Number(d.sv_maxclients||i.vars?.sv_maxClients||0),serverName:d.hostname||i.vars?.sv_projectName||'HighLife Roleplay',connectUrl:cfg.FIVEM_CONNECT_URL||'#',lastUpdated:new Date().toISOString()});
  }catch{return NextResponse.json({configured:true,online:false,players:0,maxPlayers:0,serverName:'HighLife Roleplay',connectUrl:cfg.FIVEM_CONNECT_URL||'#',lastUpdated:new Date().toISOString()});}
}
