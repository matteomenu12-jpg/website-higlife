import type {MetadataRoute} from 'next';

export default function manifest():MetadataRoute.Manifest{
  return {
    name:'HighLife Roleplay',
    short_name:'HighLife RP',
    description:'De officiële HighLife Roleplay-community.',
    start_url:'/',
    display:'standalone',
    background_color:'#0d0912',
    theme_color:'#8d5bc4',
    icons:[
      {src:'/highlife-v12-logo.png',sizes:'512x512',type:'image/png',purpose:'any'},
      {src:'/icon-192.png',sizes:'192x192',type:'image/png'},
      {src:'/icon-512.png',sizes:'512x512',type:'image/png'},
    ],
  };
}
