declare namespace Cloudflare {
  interface Env {
    DB: D1Database;
    DISCORD_CLIENT_ID?: string;
    DISCORD_CLIENT_SECRET?: string;
    DISCORD_GUILD_ID?: string;
    OWNER_DISCORD_ID?: string;
    BOT_SYNC_SECRET?: string;
  }
}
