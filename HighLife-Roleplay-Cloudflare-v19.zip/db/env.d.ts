declare namespace Cloudflare {
  interface Env {
    DB: D1Database;
    DISCORD_CLIENT_ID?: string;
    DISCORD_CLIENT_SECRET?: string;
    DISCORD_GUILD_ID?: string;
    OWNER_DISCORD_ID?: string;
    BOT_SYNC_SECRET?: string;
    DISCORD_STATUS_API_URL?: string;
    DISCORD_STATUS_API_KEY?: string;
    FIVEM_SERVER_URL?: string;
    FIVEM_CONNECT_URL?: string;
  }
}
