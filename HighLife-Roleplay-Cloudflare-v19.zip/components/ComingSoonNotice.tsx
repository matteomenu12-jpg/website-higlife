export function ComingSoonNotice({title,text}:{title:string;text:string}) {
  return <section className="coming-soon-notice" aria-label="Binnenkort beschikbaar">
    <span>BINNENKORT</span>
    <div><p className="kicker">HIGHLIFE DEVELOPMENT</p><h2>{title}</h2><p>{text}</p></div>
    <a className="ghost-button" href="/announcements">Volg de updates →</a>
  </section>;
}
