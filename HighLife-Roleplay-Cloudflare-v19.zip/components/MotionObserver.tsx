'use client';
import {useEffect} from 'react';

const selector='main > section:not(.hero), main > article, .pillar-grid article, .city-showcase figure, .announcement, .blog-card, .public-team-grid article, .panel-card, .staff-metrics article, .metric-cards article, .forum-post, .topic-list > a, .service-grid article, .activity-summary article, .activity-panel';

export function MotionObserver(){
  useEffect(()=>{
    if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
    const observer=new IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target)}}},{threshold:.08,rootMargin:'0px 0px -6%'});
    const attach=()=>document.querySelectorAll(selector).forEach((element,index)=>{if(element.classList.contains('motion-ready'))return;element.classList.add('motion-ready');(element as HTMLElement).style.setProperty('--motion-delay',`${Math.min(index%6,5)*55}ms`);observer.observe(element)});
    attach();const mutations=new MutationObserver(attach);mutations.observe(document.body,{childList:true,subtree:true});
    return()=>{mutations.disconnect();observer.disconnect()};
  },[]);
  return null;
}
