'use client';

import {useEffect, useState} from 'react';

const dockLinks = [
  {label:'Home', href:'/', icon:'⌂'},
  {label:'Forum', href:'/forum', icon:'◫'},
  {label:'Chat', href:'/community', icon:'✦'},
  {label:'Account', href:'/account', icon:'◎'},
];

export function GlobalControls(){
  const [progress,setProgress]=useState(0);
  const [showTop,setShowTop]=useState(false);
  const [path,setPath]=useState('');

  useEffect(()=>{
    setPath(window.location.pathname);
    const update=()=>{
      const scrollable=document.documentElement.scrollHeight-window.innerHeight;
      setProgress(scrollable>0?Math.min(100,(window.scrollY/scrollable)*100):0);
      setShowTop(window.scrollY>520);
    };
    update();
    window.addEventListener('scroll',update,{passive:true});
    window.addEventListener('resize',update);
    return()=>{
      window.removeEventListener('scroll',update);
      window.removeEventListener('resize',update);
    };
  },[]);

  const isActive=(href:string)=>href==='/'?path==='/':path.startsWith(href);
  const hideDock=path==='/login'||path.startsWith('/staff');

  return <>
    <div className="scroll-progress" aria-hidden="true"><span style={{width:`${progress}%`}}/></div>
    <button className={`back-to-top${showTop?' visible':''}`} type="button" aria-label="Terug naar boven" onClick={()=>window.scrollTo({top:0,behavior:'smooth'})}>↑<small>TOP</small></button>
    {!hideDock&&<nav className="mobile-dock" aria-label="Snelle mobiele navigatie">
      {dockLinks.map(link=><a key={link.href} href={link.href} className={isActive(link.href)?'active':''} aria-current={isActive(link.href)?'page':undefined}><span>{link.icon}</span><small>{link.label}</small></a>)}
    </nav>}
  </>;
}
