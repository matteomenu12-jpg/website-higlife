'use client';

import {useCallback,useEffect,useMemo,useState} from 'react';

type Member={name:string;avatar:string|null;status:'online'|'idle'|'dnd'|'offline';staff:boolean;roles:string[]};
type Data={configured:boolean;available?:boolean;message?:string;updatedAt?:string;guild?:{name:string;icon:string|null;memberCount:number;onlineCount:number};staff?:Member[];members?:Member[]};
const labels={all:'Alle leden',online:'Online',staff:'Staff'} as const;

export default function DiscordCommunityStatus(){
  const [data,setData]=useState<Data|null>(null),[filter,setFilter]=useState<keyof typeof labels>('all'),[query,setQuery]=useState('');
  const load=useCallback(async()=>{try{const response=await fetch('/api/discord-status',{cache:'no-store'});setData(await response.json());}catch{setData({configured:true,available:false,message:'De Discord-statusservice is tijdelijk niet bereikbaar.'});}},[]);
  useEffect(()=>{void load();const timer=window.setInterval(()=>void load(),60000);return()=>window.clearInterval(timer);},[load]);
  const members=useMemo(()=>{const list=data?.members||[];return list.filter(member=>{const matchesFilter=filter==='all'||filter==='online'?filter==='all'||member.status!=='offline':member.staff;return matchesFilter&&member.name.toLowerCase().includes(query.trim().toLowerCase());});},[data,filter,query]);
  const avatar=(member:Member)=><span className="discord-member-avatar">{member.avatar?<img src={member.avatar} alt=""/>:member.name.slice(0,2).toUpperCase()}<i className={`presence ${member.status}`}/></span>;
  if(!data)return <section className="discord-community-shell"><p className="discord-loading">DISCORD-STATUS LADEN…</p></section>;
  if(!data.configured||data.available===false)return <section className="discord-community-shell discord-unavailable"><span>◌</span><h2>Discord-status komt eraan.</h2><p>{data.message||'De live koppeling wordt momenteel geconfigureerd.'}</p></section>;
  return <section className="discord-community-shell">
    <header className="discord-community-head"><div className="discord-guild">{data.guild?.icon?<img src={data.guild.icon} alt=""/>:<span>HL</span>}<div><p className="kicker">LIVE DISCORD COMMUNITY</p><h2>{data.guild?.name||'HighLife Roleplay'}</h2><small><i/> Live bijgewerkt · {data.updatedAt?new Date(data.updatedAt).toLocaleTimeString('nl-BE',{hour:'2-digit',minute:'2-digit'}):'—'}</small></div></div><button type="button" onClick={load}>Vernieuwen ↻</button></header>
    <div className="discord-metrics"><article><span>LEDEN</span><strong>{data.guild?.memberCount??'—'}</strong><small>volledige community</small></article><article><span>ONLINE</span><strong>{data.guild?.onlineCount??'—'}</strong><small>online, afwezig of bezig</small></article><article><span>STAFF</span><strong>{data.staff?.length??'—'}</strong><small>zichtbaar als aparte lijst</small></article></div>
    <div className="discord-staff-block"><header><p className="kicker">STAFFTEAM</p><h3>De mensen achter HighLife.</h3></header><div className="discord-staff-list">{data.staff?.length?data.staff.map(member=><article key={`staff-${member.name}`}>{avatar(member)}<div><b>{member.name}</b><small>{member.roles.join(' · ')||'Staff'}</small></div><span className={`presence-label ${member.status}`}>{member.status}</span></article>):<p>Er zijn nog geen staffrollen gekoppeld.</p>}</div></div>
    <div className="discord-members-block"><header><div><p className="kicker">COMMUNITYLEDEN</p><h3>Iedereen in de Discord.</h3></div><input value={query} onChange={event=>setQuery(event.target.value)} placeholder="Zoek een lid…" aria-label="Zoek een Discord-lid"/></header><nav aria-label="Ledenfilter">{(Object.keys(labels) as Array<keyof typeof labels>).map(key=><button className={filter===key?'active':''} onClick={()=>setFilter(key)} key={key}>{labels[key]}</button>)}</nav><p className="discord-result-count">{members.length} {members.length===1?'lid':'leden'} weergegeven</p><div className="discord-member-list">{members.map(member=><article key={`${member.name}-${member.avatar||'none'}`}>{avatar(member)}<div><b>{member.name}</b><small>{member.staff?'Stafflid':'Communitylid'}</small></div>{member.staff&&<em>STAFF</em>}</article>)}</div></div>
  </section>;
}
