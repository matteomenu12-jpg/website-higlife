import {SiteHeader} from '@/components/SiteHeader';
import DiscordCommunityStatus from '@/components/DiscordCommunityStatus';

export const dynamic='force-dynamic';
export default function DiscordPage(){return <main className="inner-page discord-page"><SiteHeader active="Discord"/><section className="page-hero compact discord-hero"><p className="eyebrow"><span/> HIGHLIFE COMMUNITY</p><h1>Discord.<br/><em>Live verbonden.</em></h1><p>Bekijk de live communitystatus, online leden en het HighLife-staffteam.</p></section><DiscordCommunityStatus/></main>}
