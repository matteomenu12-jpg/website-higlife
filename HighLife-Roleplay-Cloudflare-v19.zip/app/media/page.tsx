/* eslint-disable @next/next/no-img-element */
import {SiteHeader} from '@/components/SiteHeader';
const cityImages=[
  ['/highlife-city-coast.webp','De noordelijke route','Trein en vliegtuig aan de kust van HighLife'],
  ['/highlife-city-sunset.jpg','Downtown na zonsondergang','HighLife skyline bij zonsondergang'],
  ['/highlife-city-district.jpg','Een stad vol kansen','Moderne stadswijk van HighLife'],
];
export default function Media(){return <main className="inner-page"><SiteHeader active="Media"/><section className="page-hero compact"><p className="eyebrow"><span/> BEELDEN UIT DE STAD</p><h1>Stad in beeld.</h1><p>De officiële stadsbeelden van HighLife Roleplay.</p></section><section className="media-grid city-media-grid">{cityImages.map((image,index)=><figure className="media-card city-media-card" key={image[0]}><img src={image[0]} alt={image[2]}/><span>{String(index+1).padStart(2,'0')}</span><figcaption><h2>{image[1]}</h2></figcaption></figure>)}</section></main>}
