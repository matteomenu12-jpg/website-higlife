import { env } from 'cloudflare:workers';
import { NextResponse } from 'next/server';

export const dynamic='force-dynamic';
type FiveMPlayer={id?:number;name?:string;ping?:number};
const clean=(value:string|undefined,fallback:string)=>String(value||fallback).replace(/\^[0-9]/g,'').replace(/[<>]/g,'').trim().slice(0,120);
export async function GET(){
  const cfg=env as unknown as {FIVEM_SERVER_URL?:string;FIVEM_CONNECT_URL?:string};
  const empty={configured:false,online:false,players:0,maxPlayers:0,serverName:'HighLife Roleplay',connectUrl:cfg.FIVEM_CONNECT_URL||'#',map:'Los Santos',gameType:'Roleplay',playerList:[],lastUpdated:new Date().toISOString()};
  if(!cfg.FIVEM_SERVER_URL)return NextResponse.json(empty,{headers:{'Cache-Control':'no-store'}});
  try{
    const base=cfg.FIVEM_SERVER_URL.replace(/\/$/,'');
    const [dynamic,info,playersResponse]=await Promise.all([fetch(`${base}/dynamic.json`,{signal:AbortSignal.timeout(6000)}),fetch(`${base}/info.json`,{signal:AbortSignal.timeout(6000)}),fetch(`${base}/players.json`,{signal:AbortSignal.timeout(6000)})]);
    if(!dynamic.ok||!info.ok)throw new Error('FiveM endpoint reageert niet');
    const d=await dynamic.json() as {clients?:number;sv_maxclients?:number;hostname?:string;mapname?:string;gametype?:string};const i=await info.json() as {vars?:Record<string,string>};
    const rawPlayers=playersResponse.ok?await playersResponse.json() as FiveMPlayer[]:[];
    const playerList=rawPlayers.slice(0,256).map(player=>({id:Number(player.id||0),name:clean(player.name,'Onbekende speler'),ping:Math.max(0,Math.min(Number(player.ping||0),999))})).sort((a,b)=>a.name.localeCompare(b.name,'nl'));
    return NextResponse.json({configured:true,online:true,players:Number(d.clients||playerList.length),maxPlayers:Number(d.sv_maxclients||i.vars?.sv_maxClients||0),serverName:clean(d.hostname||i.vars?.sv_projectName,'HighLife Roleplay'),connectUrl:cfg.FIVEM_CONNECT_URL||'#',map:clean(d.mapname||i.vars?.mapname,'Los Santos'),gameType:clean(d.gametype||i.vars?.gametype,'Roleplay'),playerList,lastUpdated:new Date().toISOString()},{headers:{'Cache-Control':'no-store'}});
  }catch{return NextResponse.json({...empty,configured:true},{headers:{'Cache-Control':'no-store'}});}
}
