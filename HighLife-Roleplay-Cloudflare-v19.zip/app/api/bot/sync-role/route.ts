import { env } from 'cloudflare:workers';
import { NextResponse } from 'next/server';
import { sha256 } from '@/lib/auth';
import { database, ensureDb, writeAudit } from '@/lib/db';

const SYNCABLE_ROLES = new Set(['administrator','moderator','communications']);

export async function POST(request:Request){
  const cfg=env as unknown as {BOT_SYNC_SECRET?:string};
  const supplied=(request.headers.get('authorization')||'').replace(/^Bearer\s+/i,'');
  if(!cfg.BOT_SYNC_SECRET||!supplied||(await sha256(supplied))!==(await sha256(cfg.BOT_SYNC_SECRET))) return NextResponse.json({error:'Bot niet geautoriseerd'},{status:401});
  const {discordId,roleSlug,enabled}=await request.json() as {discordId:string;roleSlug:string;enabled:boolean};
  if(!/^\d{16,22}$/.test(discordId)||!SYNCABLE_ROLES.has(roleSlug)||typeof enabled!=='boolean') return NextResponse.json({error:'Ongeldige sync-opdracht'},{status:400});
  await ensureDb(); const db=database();
  const user=await db.prepare(`SELECT id FROM users WHERE discord_id=?`).bind(discordId).first<{id:number}>();
  if(!user) return NextResponse.json({error:'Gebruiker moet eerst via Discord op de website inloggen'},{status:404});
  const role=await db.prepare(`SELECT id,name FROM roles WHERE slug=?`).bind(roleSlug).first<{id:number;name:string}>();
  if(!role) return NextResponse.json({error:'Website-rol niet gevonden'},{status:404});
  if(enabled) await db.prepare(`INSERT OR IGNORE INTO user_roles (user_id,role_id,assigned_by,assigned_at) VALUES (?,?,NULL,?)`).bind(user.id,role.id,new Date().toISOString()).run();
  else await db.prepare(`DELETE FROM user_roles WHERE user_id=? AND role_id=?`).bind(user.id,role.id).run();
  await writeAudit(null,enabled?'bot.role.add':'bot.role.remove','user',String(user.id),`${role.name} gesynchroniseerd vanuit Discord`);
  return NextResponse.json({ok:true});
}
