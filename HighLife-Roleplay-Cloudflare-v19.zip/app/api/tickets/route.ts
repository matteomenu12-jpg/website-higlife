import {NextResponse} from 'next/server';
import {sameOrigin,userFromRequest} from '@/lib/auth';
import {database,ensureDb,writeAudit} from '@/lib/db';

export async function GET(request:Request){
  const user=await userFromRequest(request);if(!user)return NextResponse.json({error:'Log eerst in met Discord.'},{status:401});
  await ensureDb();const rows=await database().prepare(`SELECT t.id,t.subject,t.category,t.priority,t.status,t.created_at AS createdAt,t.updated_at AS updatedAt,(SELECT COUNT(*) FROM ticket_messages m WHERE m.ticket_id=t.id) AS messages FROM tickets t WHERE t.user_id=? ORDER BY t.updated_at DESC LIMIT 60`).bind(user.id).all();
  return NextResponse.json({tickets:rows.results});
}

export async function POST(request:Request){
  if(!sameOrigin(request))return NextResponse.json({error:'Ongeldige aanvraag.'},{status:403});
  const user=await userFromRequest(request);if(!user)return NextResponse.json({error:'Log eerst in met Discord.'},{status:401});
  const input=await request.json() as {subject?:string;category?:string;priority?:string;body?:string};
  const subject=String(input.subject||'').trim(),body=String(input.body||'').trim(),category=String(input.category||'Algemene hulp').trim(),priority=String(input.priority||'normal');
  if(subject.length<5||subject.length>100||body.length<15||body.length>4000)return NextResponse.json({error:'Gebruik een duidelijke titel en minstens 15 tekens uitleg.'},{status:400});
  if(!['normal','high','urgent'].includes(priority))return NextResponse.json({error:'Ongeldige prioriteit.'},{status:400});
  const allowedCategories=['Algemene hulp','Account & Discord','FiveM & verbinding','Speler melden','Aankoop & donatie','Overig'];
  if(!allowedCategories.includes(category))return NextResponse.json({error:'Ongeldige categorie.'},{status:400});
  await ensureDb();const db=database(),now=new Date().toISOString();
  const result=await db.prepare(`INSERT INTO tickets (user_id,subject,category,priority,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)`).bind(user.id,subject,category,priority,'open',now,now).run();
  const ticketId=Number(result.meta.last_row_id);await db.prepare(`INSERT INTO ticket_messages (ticket_id,user_id,body,staff,created_at) VALUES (?,?,?,0,?)`).bind(ticketId,user.id,body,now).run();
  await writeAudit(user.id,'ticket.create','ticket',String(ticketId),subject);return NextResponse.json({ok:true,id:ticketId});
}
