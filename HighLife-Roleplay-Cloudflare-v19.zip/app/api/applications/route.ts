import { NextResponse } from 'next/server';
import { database, ensureDb, writeAudit } from '@/lib/db';
import { sameOrigin, userFromRequest } from '@/lib/auth';

const types=new Set(['staff','politie','ambulance','developer']);
export async function GET(request:Request){
  const user=await userFromRequest(request);if(!user)return NextResponse.json({error:'Niet ingelogd'},{status:401});await ensureDb();
  const rows=await database().prepare(`SELECT id,type,status,staff_note AS staffNote,created_at AS createdAt,updated_at AS updatedAt FROM applications WHERE user_id=? ORDER BY created_at DESC`).bind(user.id).all();
  return NextResponse.json({applications:rows.results});
}
export async function POST(request:Request){
  if(!sameOrigin(request))return NextResponse.json({error:'Ongeldige aanvraag'},{status:403});const user=await userFromRequest(request);if(!user)return NextResponse.json({error:'Log eerst in via Discord'},{status:401});await ensureDb();
  const body=await request.json() as {type?:string;motivation?:string;experience?:string};const type=String(body.type||'');const motivation=String(body.motivation||'').trim();const experience=String(body.experience||'').trim();
  if(!types.has(type)||motivation.length<40||motivation.length>2000||experience.length<20||experience.length>1500)return NextResponse.json({error:'Vul alle velden volledig in'},{status:400});
  const open=await database().prepare(`SELECT id FROM applications WHERE user_id=? AND type=? AND status IN ('pending','reviewing')`).bind(user.id,type).first();if(open)return NextResponse.json({error:'Je hebt hiervoor al een open sollicitatie'},{status:409});
  const now=new Date().toISOString();const result=await database().prepare(`INSERT INTO applications (user_id,type,motivation,experience,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)`).bind(user.id,type,motivation,experience,'pending',now,now).run();
  await writeAudit(user.id,'application.create','application',String(result.meta.last_row_id),`Nieuwe ${type}-sollicitatie`);return NextResponse.json({ok:true});
}
