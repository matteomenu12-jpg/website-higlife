import {env} from 'cloudflare:workers';
import {NextResponse} from 'next/server';

export const dynamic='force-dynamic';
type Config={DISCORD_STATUS_API_URL?:string;DISCORD_STATUS_API_KEY?:string};

export async function GET(){
  const config=env as unknown as Config;
  if(!config.DISCORD_STATUS_API_URL||!config.DISCORD_STATUS_API_KEY)return NextResponse.json({configured:false,message:'De Discord-statuskoppeling wordt nog geconfigureerd.'},{headers:{'Cache-Control':'no-store'}});
  try{
    const response=await fetch(config.DISCORD_STATUS_API_URL,{headers:{Authorization:`Bearer ${config.DISCORD_STATUS_API_KEY}`,'Accept':'application/json'},signal:AbortSignal.timeout(8000),cf:{cacheTtl:0,cacheEverything:false}});
    if(!response.ok)throw new Error('Discord-statusservice reageert niet');
    const data=await response.json();
    return NextResponse.json({configured:true,...data},{headers:{'Cache-Control':'no-store'}});
  }catch{return NextResponse.json({configured:true,available:false,message:'De Discord-statusservice is tijdelijk niet bereikbaar.'},{status:503,headers:{'Cache-Control':'no-store'}});}
}
