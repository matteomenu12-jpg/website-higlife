import { NextResponse } from 'next/server';
import { cookieFromRequest, sameOrigin, SESSION_COOKIE, sha256 } from '@/lib/auth';
import { database, ensureDb } from '@/lib/db';
export async function POST(request:Request){ if(!sameOrigin(request))return NextResponse.json({error:'Ongeldige herkomst'},{status:403}); const token=cookieFromRequest(request,SESSION_COOKIE); if(token){await ensureDb();await database().prepare(`DELETE FROM sessions WHERE token_hash=?`).bind(await sha256(token)).run();} const response=NextResponse.redirect(new URL('/',request.url),303); response.cookies.delete(SESSION_COOKIE); return response; }
