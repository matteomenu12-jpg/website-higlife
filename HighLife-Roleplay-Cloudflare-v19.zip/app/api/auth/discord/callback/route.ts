import { env } from 'cloudflare:workers';
import { NextResponse } from 'next/server';
import { cookieFromRequest, createSession, SESSION_COOKIE } from '@/lib/auth';
import { database, ensureDb, writeAudit } from '@/lib/db';
import { HIGHLIFE_OWNER_DISCORD_ID } from '@/lib/owner';

type DiscordUser={id:string;username:string;global_name?:string|null;avatar?:string|null};
export async function GET(request:Request){
  const reqUrl=new URL(request.url); const origin=reqUrl.origin; const code=reqUrl.searchParams.get('code'); const state=reqUrl.searchParams.get('state'); const expected=cookieFromRequest(request,'nh_oauth_state');
  if(!code||!state||state!==expected) return NextResponse.redirect(new URL('/login?error=invalid-state',origin));
  const cfg=env as unknown as {DISCORD_CLIENT_ID?:string;DISCORD_CLIENT_SECRET?:string;OWNER_DISCORD_ID?:string}; const clientId=cfg.DISCORD_CLIENT_ID||'1540778050952765591'; if(!cfg.DISCORD_CLIENT_SECRET) return NextResponse.redirect(new URL('/login?error=not-configured',origin));
  const tokenRes=await fetch('https://discord.com/api/v10/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:clientId,client_secret:cfg.DISCORD_CLIENT_SECRET,grant_type:'authorization_code',code,redirect_uri:`${origin}/api/auth/discord/callback`})});
  if(!tokenRes.ok) return NextResponse.redirect(new URL('/login?error=token',origin)); const token=await tokenRes.json() as {access_token:string};
  const userRes=await fetch('https://discord.com/api/v10/users/@me',{headers:{Authorization:`Bearer ${token.access_token}`}}); if(!userRes.ok)return NextResponse.redirect(new URL('/login?error=profile',origin)); const discord=await userRes.json() as DiscordUser;
  await ensureDb(); const db=database(); const now=new Date().toISOString(); const avatar=discord.avatar?`https://cdn.discordapp.com/avatars/${discord.id}/${discord.avatar}.png`:null;
  await db.prepare(`INSERT INTO users (discord_id,username,display_name,avatar,created_at,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT(discord_id) DO UPDATE SET username=excluded.username,display_name=excluded.display_name,avatar=excluded.avatar,updated_at=excluded.updated_at`).bind(discord.id,discord.username,discord.global_name||discord.username,avatar,now,now).run();
  const user=await db.prepare(`SELECT id FROM users WHERE discord_id=?`).bind(discord.id).first<{id:number}>(); if(!user)throw new Error('Account kon niet worden opgeslagen');
  if(discord.id===(cfg.OWNER_DISCORD_ID||HIGHLIFE_OWNER_DISCORD_ID)){ await db.prepare(`INSERT OR IGNORE INTO user_roles (user_id,role_id,assigned_by,assigned_at) SELECT ?,id,?,? FROM roles WHERE slug='owner'`).bind(user.id,user.id,now).run(); }
  await writeAudit(user.id,'auth.login','user',String(user.id),'Ingelogd via Discord'); const session=await createSession(user.id);
  const response=NextResponse.redirect(new URL('/account',origin)); response.cookies.set(SESSION_COOKIE,session.token,{httpOnly:true,sameSite:'lax',secure:origin.startsWith('https:'),path:'/',expires:session.expires,maxAge:60*60*24*14}); response.cookies.delete('nh_oauth_state'); return response;
}
