import { NextResponse } from 'next/server';
import { database, ensureDb, writeAudit } from '@/lib/db';
import { sameOrigin, userFromRequest } from '@/lib/auth';

const channels = new Set(['algemeen','media','vragen','suggesties']);

export async function GET(request:Request){
  await ensureDb();
  const channel=new URL(request.url).searchParams.get('channel')||'algemeen';
  if(!channels.has(channel)) return NextResponse.json({error:'Onbekend kanaal'},{status:400});
  const rows=await database().prepare(`SELECT m.id,m.channel,m.content,m.reported,m.created_at AS createdAt,u.display_name AS displayName,u.username,u.avatar,GROUP_CONCAT(r.slug) AS roles FROM chat_messages m JOIN users u ON u.id=m.user_id LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id WHERE m.channel=? AND m.deleted=0 GROUP BY m.id ORDER BY m.created_at DESC LIMIT 60`).bind(channel).all();
  return NextResponse.json({messages:rows.results.reverse()});
}

export async function POST(request:Request){
  if(!sameOrigin(request)) return NextResponse.json({error:'Ongeldige aanvraag'},{status:403});
  const user=await userFromRequest(request); if(!user)return NextResponse.json({error:'Log eerst in via Discord'},{status:401});
  await ensureDb(); const body=await request.json() as {action?:string;channel?:string;content?:string;id?:number};
  if(body.action==='report'){
    if(!body.id)return NextResponse.json({error:'Bericht ontbreekt'},{status:400});
    await database().prepare(`UPDATE chat_messages SET reported=1 WHERE id=? AND deleted=0`).bind(body.id).run();
    await writeAudit(user.id,'chat.report','chat_message',String(body.id),'Communitybericht gemeld');
    return NextResponse.json({ok:true});
  }
  const channel=String(body.channel||'algemeen'); const content=String(body.content||'').trim();
  if(!channels.has(channel)||content.length<1||content.length>500)return NextResponse.json({error:'Gebruik 1 tot 500 tekens'},{status:400});
  const last=await database().prepare(`SELECT created_at AS createdAt FROM chat_messages WHERE user_id=? ORDER BY created_at DESC LIMIT 1`).bind(user.id).first<{createdAt:string}>();
  if(last&&Date.now()-new Date(last.createdAt).getTime()<2000)return NextResponse.json({error:'Wacht even voor je opnieuw stuurt'},{status:429});
  await database().prepare(`INSERT INTO chat_messages (user_id,channel,content,reported,deleted,created_at) VALUES (?,?,?,0,0,?)`).bind(user.id,channel,content,new Date().toISOString()).run();
  return NextResponse.json({ok:true});
}
