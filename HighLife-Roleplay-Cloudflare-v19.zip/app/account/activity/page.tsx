import {redirect} from 'next/navigation';
import {getCurrentUser} from '@/lib/auth';
import {database,ensureDb} from '@/lib/db';
import {SiteHeader} from '@/components/SiteHeader';

export const dynamic='force-dynamic';
type Topic={id:number;title:string;category:string;updatedAt:string;replies:number};
type Application={id:number;type:string;status:string;updatedAt:string};

export default async function Activity(){
  const user=await getCurrentUser();if(!user)redirect('/login');await ensureDb();const db=database();
  const [topics,applications,replies]=await Promise.all([
    db.prepare(`SELECT t.id,t.title,t.category,t.updated_at AS updatedAt,(SELECT COUNT(*) FROM forum_replies r WHERE r.topic_id=t.id) AS replies FROM forum_topics t WHERE t.user_id=? ORDER BY t.updated_at DESC LIMIT 12`).bind(user.id).all<Topic>(),
    db.prepare(`SELECT id,type,status,updated_at AS updatedAt FROM applications WHERE user_id=? ORDER BY updated_at DESC LIMIT 12`).bind(user.id).all<Application>(),
    db.prepare(`SELECT COUNT(*) AS count FROM forum_replies WHERE user_id=?`).bind(user.id).first<{count:number}>(),
  ]);
  return <main className="inner-page"><SiteHeader active="" user={user}/><section className="page-hero compact activity-hero"><p className="eyebrow"><span/> JOUW HIGHLIFE-GESCHIEDENIS</p><h1>Mijn activiteit.</h1><p>Bekijk jouw forumtopics, reacties en sollicitaties vanuit één persoonlijk overzicht.</p></section><section className="activity-summary"><article><span>TOPICS</span><strong>{topics.results.length}</strong><p>Recente topics</p></article><article><span>REACTIES</span><strong>{replies?.count||0}</strong><p>Forumreacties</p></article><article><span>SOLLICITATIES</span><strong>{applications.results.length}</strong><p>Recente aanvragen</p></article></section><section className="activity-grid"><article className="activity-panel"><p className="kicker">MIJN FORUMTOPICS</p>{topics.results.length?topics.results.map(topic=><a href={`/forum/${topic.id}`} key={topic.id}><span>{topic.category}</span><b>{topic.title}</b><small>{topic.replies} reacties · {new Date(topic.updatedAt).toLocaleDateString('nl-BE')}</small></a>):<div className="empty-card">Je hebt nog geen forumtopic aangemaakt.</div>}</article><article className="activity-panel"><p className="kicker">MIJN SOLLICITATIES</p>{applications.results.length?applications.results.map(item=><div className="activity-row" key={item.id}><span>{item.type}</span><b>{item.status}</b><small>{new Date(item.updatedAt).toLocaleDateString('nl-BE')}</small></div>):<div className="empty-card">Je hebt nog geen sollicitatie verstuurd.</div>}<a className="panel-page-link" href="/apply">Open sollicitatiecentrum →</a></article></section></main>;
}
