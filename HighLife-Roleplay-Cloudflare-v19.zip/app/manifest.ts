import type {MetadataRoute} from 'next';

export default function manifest():MetadataRoute.Manifest{
  return {
    name:'HighLife Roleplay',
    short_name:'HighLife RP',
    description:'De officiële HighLife Roleplay-community.',
    start_url:'/',
    display:'standalone',
    background_color:'#17101f',
    theme_color:'#17101f',
    icons:[
      {src:'/icon-192.png',sizes:'192x192',type:'image/png',purpose:'any'},
      {src:'/icon-512.png',sizes:'512x512',type:'image/png',purpose:'any'},
      {src:'/icon-512-maskable.png',sizes:'512x512',type:'image/png',purpose:'maskable'},
    ],
  };
}
