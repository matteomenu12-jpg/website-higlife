import {SiteHeader} from '@/components/SiteHeader';
import {database,ensureDb} from '@/lib/db';

export const dynamic='force-dynamic';
type TeamMember={id:number;name:string;rank:string};

export default async function StaffTeamPage(){
  await ensureDb();
  const result=await database().prepare(`SELECT id,name,rank FROM staff_team ORDER BY sort_order,id`).all<TeamMember>();
  const team=result.results;
  return <main className="inner-page"><SiteHeader active="Staffteam"/>
    <section className="page-hero compact"><p className="eyebrow"><span/> DE MENSEN ACHTER HIGHLIFE</p><h1>Ons staffteam.</h1><p>Het team dat de community ondersteunt en de stad mee in beweging houdt.</p></section>
    <section className="public-team-section">
      {team.length?<div className="public-team-grid">{team.map((member,index)=><article key={member.id}><span>{String(index+1).padStart(2,'0')}</span><div><h2>{member.name}</h2><p>{member.rank}</p></div></article>)}</div>:<div className="team-empty"><span>✦</span><h2>COMING SOON</h2><p>Het officiële HighLife-staffteam wordt binnenkort bekendgemaakt.</p></div>}
    </section>
  </main>;
}
