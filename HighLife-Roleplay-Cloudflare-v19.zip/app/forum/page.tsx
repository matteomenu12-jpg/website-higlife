import {SiteHeader} from '@/components/SiteHeader';import ForumBoard from '@/components/ForumBoard';import {getCurrentUser} from '@/lib/auth';
export const dynamic='force-dynamic';
export default async function Forum(){const user=await getCurrentUser();return <main className="inner-page"><SiteHeader active="Forum" user={user}/><section className="page-hero compact"><p className="eyebrow"><span/> COMMUNITY BOARD</p><h1>Forum.</h1><p>Maak topics, deel ideeën en bouw samen verder aan HighLife.</p></section><ForumBoard signedIn={!!user}/></main>}
