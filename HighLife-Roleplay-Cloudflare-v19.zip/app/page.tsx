import {SiteHeader} from '@/components/SiteHeader';
/* eslint-disable @next/next/no-img-element, @next/next/no-html-link-for-pages */

export default function Home() {
  return (
    <main id="top" className="site-shell">
      <SiteHeader active="Home"/>

      <section className="hero">
        <div className="hero-glow" aria-hidden="true" />
        <div className="v13-hero-copy">
          <p className="eyebrow">NEDERLANDSE FIVEM ROLEPLAY</p>
          <h1>Jouw verhaal.<br/><em>Jouw HighLife.</em></h1>
          <p>Een stad met ruimte voor lange verhaallijnen, eigen ondernemingen en roleplay die verdergaat dan één avond.</p>
          <div className="hero-actions"><a className="primary-button" href="/login">Word onderdeel <span>→</span></a><a className="text-button" href="#discover">Ontdek de stad ↓</a></div>
        </div>
        <div className="hero-caption"><span>01</span><p>Miami skyline<br/><small>HighLife · Seizoen 01</small></p></div>
      </section>
      <section className="city-showcase v19-city-showcase"><div className="city-showcase-head"><div><p className="kicker">BEELDEN UIT DE STAD</p><h2>HighLife<br/>in beweging.</h2></div><p>Van palmboulevard tot skyline: iedere wijk vormt het decor voor een nieuw verhaal.</p></div><div className="v19-city-grid"><figure className="city-slide city-slide-left city-wide"><img src="/highlife-city-coast.webp" alt="Trein en vliegtuig aan de kust van HighLife"/><figcaption><span>01</span><b>De noordelijke route</b></figcaption></figure><figure className="city-slide city-slide-right"><img src="/highlife-city-palms-overlook.jpg" alt="Tropische wijk van HighLife vanuit de hoogte"/><figcaption><span>02</span><b>Palms Overlook</b></figcaption></figure><figure className="city-slide city-slide-left"><img src="/highlife-city-palms-boulevard.jpg" alt="Boulevard met palmbomen in HighLife"/><figcaption><span>03</span><b>Palms Boulevard</b></figcaption></figure><figure className="city-slide city-slide-right city-tall"><img src="/highlife-city-sunset.jpg" alt="HighLife skyline bij zonsondergang"/><figcaption><span>04</span><b>Downtown Sunset</b></figcaption></figure><figure className="city-slide city-slide-left city-wide"><img src="/highlife-city-district.jpg" alt="Moderne stadswijk van HighLife"/><figcaption><span>05</span><b>District vol kansen</b></figcaption></figure></div></section>
      <section className="home-intro" id="discover"><p className="section-index">01 — WELKOM</p><div><h2>Geen haastwerk.<br/>Wel verhalen die blijven.</h2><p>HighLife is gebouwd voor spelers die hun personage willen ontwikkelen. Je begint klein, leert mensen kennen en verdient stap voor stap je plaats in de stad.</p></div><aside><span>SEIZOEN</span><strong>01</strong><small>De stad schrijft verder</small></aside></section>
      <section className="home-routes"><header><p className="section-index">02 — JOUW ROUTE</p><h2>Waar begin jij?</h2></header><div><a href="/apply"><span>01</span><h3>Hulpdiensten</h3><p>Werk samen, blijf kalm en maak keuzes waar anderen op rekenen.</p><b>Bekijk sollicitaties →</b></a><a href="/forum"><span>02</span><h3>Ondernemen</h3><p>Bouw een netwerk op en geef je eigen zaak een plek in de economie.</p><b>Open het forum →</b></a><a href="/community"><span>03</span><h3>Community</h3><p>Leer de spelers achter de personages kennen en blijf op de hoogte.</p><b>Naar de community →</b></a></div></section>
      <section className="home-cta"><div><p className="section-index">03 — AANMELDEN</p><h2>Klaar voor je eerste dag?</h2><p>Lees de regels, koppel je Discord-account en maak kennis met de community.</p></div><div><a className="primary-button" href="/login">Login met Discord →</a><a className="text-button" href="/rules">Lees eerst de regels</a></div></section>
      <footer><a className="brand" href="/"><img className="brand-logo" src="/highlife-v12-logo.png" alt="Bewegend HighLife-logo"/><span><b>HIGHLIFE</b><small>ROLEPLAY</small></span></a><p>Een onafhankelijke FiveM-community. Niet verbonden aan Rockstar Games of Cfx.re.</p><div><a href="/rules">Regels</a><a href="/announcements">Nieuws</a><a href="/community">Community</a><a href="/account">Account</a></div></footer>
    </main>
  );
}
