import { cookies } from 'next/headers';
import { database, ensureDb, getUserWithPermissions } from './db';
export const SESSION_COOKIE='nh_session';
export async function sha256(value:string){ const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)); return [...new Uint8Array(bytes)].map(b=>b.toString(16).padStart(2,'0')).join(''); }
export function randomToken(bytes=32){ const data=new Uint8Array(bytes); crypto.getRandomValues(data); return [...data].map(b=>b.toString(16).padStart(2,'0')).join(''); }
export async function createSession(userId:number){ await ensureDb(); const token=randomToken(); const hash=await sha256(token); const now=new Date(); const expires=new Date(now.getTime()+1000*60*60*24*14); await database().prepare(`INSERT INTO sessions (token_hash,user_id,expires_at,created_at) VALUES (?,?,?,?)`).bind(hash,userId,expires.toISOString(),now.toISOString()).run(); return {token,expires}; }
export async function getSessionUser(token?:string|null){ if(!token)return null; await ensureDb(); const hash=await sha256(token); const row=await database().prepare(`SELECT user_id AS userId FROM sessions WHERE token_hash=? AND expires_at>?`).bind(hash,new Date().toISOString()).first<{userId:number}>(); return row?getUserWithPermissions(row.userId):null; }
export async function getCurrentUser(){ const jar=await cookies(); return getSessionUser(jar.get(SESSION_COOKIE)?.value); }
export function cookieFromRequest(request:Request,name:string){ const raw=request.headers.get('cookie')||''; const item=raw.split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'=')); return item?decodeURIComponent(item.slice(name.length+1)):null; }
export async function userFromRequest(request:Request){ return getSessionUser(cookieFromRequest(request,SESSION_COOKIE)); }
export function sameOrigin(request:Request){ const origin=request.headers.get('origin'); return !origin || origin===new URL(request.url).origin; }
