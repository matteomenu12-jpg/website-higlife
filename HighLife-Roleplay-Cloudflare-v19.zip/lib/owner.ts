import type { SessionUser } from './db';

export const HIGHLIFE_OWNER_DISCORD_ID='1086683912320856217';
export function isHighLifeOwner(user:SessionUser|null|undefined){return !!user&&user.discordId===HIGHLIFE_OWNER_DISCORD_ID;}
