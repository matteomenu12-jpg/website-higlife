export const PERMISSIONS = ['staff.access','announcements.create','announcements.edit','announcements.delete','announcements.publish','members.view','members.assign_roles','roles.manage','moderation.view','audit.view','tickets.manage'] as const;
export type Permission = typeof PERMISSIONS[number];
export const DEFAULT_ROLES = [
  { slug:'owner', name:'Eigenaar', color:'#f6b94a', level:100, permissions:['*'] },
  { slug:'administrator', name:'Administrator', color:'#ff7657', level:80, permissions:['staff.access','announcements.create','announcements.edit','announcements.delete','announcements.publish','members.view','members.assign_roles','roles.manage','moderation.view','audit.view','tickets.manage'] },
  { slug:'moderator', name:'Moderator', color:'#58a6ff', level:50, permissions:['staff.access','members.view','moderation.view','tickets.manage'] },
  { slug:'communications', name:'Communicatie', color:'#ff3fbd', level:40, permissions:['staff.access','announcements.create','announcements.edit','announcements.publish'] },
  { slug:'support', name:'Support', color:'#22e6c1', level:35, permissions:['staff.access','tickets.manage'] },
];
export function hasPermission(permissions:string[], permission:Permission) { return permissions.includes('*') || permissions.includes(permission); }
