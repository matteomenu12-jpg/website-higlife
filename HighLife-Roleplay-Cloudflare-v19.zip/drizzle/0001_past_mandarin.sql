CREATE TABLE `applications` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` integer NOT NULL,
	`type` text NOT NULL,
	`motivation` text NOT NULL,
	`experience` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`staff_note` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `chat_messages` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` integer NOT NULL,
	`channel` text NOT NULL,
	`content` text NOT NULL,
	`reported` integer DEFAULT false NOT NULL,
	`deleted` integer DEFAULT false NOT NULL,
	`created_at` text NOT NULL
);
