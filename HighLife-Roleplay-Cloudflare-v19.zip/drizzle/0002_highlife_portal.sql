CREATE TABLE IF NOT EXISTS `blogs` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`title` text NOT NULL,`slug` text NOT NULL,`excerpt` text NOT NULL,`body` text NOT NULL,`status` text NOT NULL,`author_id` integer,`created_at` text NOT NULL,`updated_at` text NOT NULL,`published_at` text);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `blogs_slug_unique` ON `blogs` (`slug`);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `forum_topics` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`user_id` integer NOT NULL,`category` text NOT NULL,`title` text NOT NULL,`body` text NOT NULL,`locked` integer DEFAULT false NOT NULL,`created_at` text NOT NULL,`updated_at` text NOT NULL);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `forum_replies` (`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,`topic_id` integer NOT NULL,`user_id` integer NOT NULL,`body` text NOT NULL,`created_at` text NOT NULL,`updated_at` text NOT NULL);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `idx_blogs_status_date` ON `blogs` (`status`,`published_at`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `idx_topics_updated` ON `forum_topics` (`updated_at`);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS `idx_replies_topic` ON `forum_replies` (`topic_id`,`created_at`);
