# HighLife Roleplay Website — V13

De officiële website voor de HighLife Roleplay-community. V13 bevat de volledig
herbouwde publieke website, Discord-login, accounts, forum, tickets,
sollicitaties, communityfuncties en het afgeschermde staffpanel.

## Cloudflare deployment

- Build command: `npm run build`
- Deploy command: `npx wrangler deploy`
- Root directory: `/`
- Node.js version: `22`

Cloudflare gebruikt `wrangler.jsonc` om de gebouwde Worker en de statische bestanden te publiceren. De website krijgt automatisch een gratis `workers.dev`-adres.

## Benodigde koppelingen

De interactieve functies gebruiken de Cloudflare D1-binding `DB`. Discord-login
vereist daarnaast `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET`,
`DISCORD_REDIRECT_URI`, `SESSION_SECRET` en `OWNER_DISCORD_ID` als beveiligde
Worker-variabelen. Gebruik als redirect-URL:
`https://website-higlife.highlife.workers.dev/api/auth/discord/callback`.

Plaats nooit Discord-secrets, tokens of andere wachtwoorden in deze publieke repository.
