import 'dotenv/config';
import { Client, GatewayIntentBits, PermissionFlagsBits, REST, Routes, SlashCommandBuilder } from 'discord.js';

const required=['DISCORD_BOT_TOKEN','DISCORD_CLIENT_ID','DISCORD_GUILD_ID','HIGHLIFE_SITE_URL','BOT_SYNC_SECRET'];
for(const key of required) if(!process.env[key]) throw new Error(`Ontbrekende instelling: ${key}`);

const roleMap={
  administrator:process.env.ROLE_ADMINISTRATOR_ID,
  moderator:process.env.ROLE_MODERATOR_ID,
  communications:process.env.ROLE_COMMUNICATIONS_ID,
};

const commands=[
  new SlashCommandBuilder().setName('website').setDescription('Open de HighLife-website en login met Discord.'),
  new SlashCommandBuilder().setName('syncroles').setDescription('Synchroniseer alle ingestelde staffrollen met de website.').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
].map(command=>command.toJSON());

async function sendRole(discordId,roleSlug,enabled){
  const response=await fetch(`${process.env.HIGHLIFE_SITE_URL.replace(/\/$/,'')}/api/bot/sync-role`,{method:'POST',headers:{Authorization:`Bearer ${process.env.BOT_SYNC_SECRET}`,'Content-Type':'application/json'},body:JSON.stringify({discordId,roleSlug,enabled})});
  if(!response.ok&&response.status!==404) console.error(`Sync mislukt voor ${discordId}/${roleSlug}:`,response.status,await response.text());
}

async function syncMember(member){
  await Promise.all(Object.entries(roleMap).filter(([,id])=>id).map(([slug,id])=>sendRole(member.id,slug,member.roles.cache.has(id))));
}

const rest=new REST({version:'10'}).setToken(process.env.DISCORD_BOT_TOKEN);
await rest.put(Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID,process.env.DISCORD_GUILD_ID),{body:commands});

const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers]});
client.once('ready',()=>console.log(`HighLife bot online als ${client.user.tag}`));
client.on('guildMemberUpdate',(_oldMember,newMember)=>syncMember(newMember).catch(console.error));
client.on('interactionCreate',async interaction=>{
  if(!interaction.isChatInputCommand()) return;
  if(interaction.commandName==='website') return interaction.reply({content:`Login op ${process.env.HIGHLIFE_SITE_URL}/login`,ephemeral:true});
  if(interaction.commandName==='syncroles'){
    await interaction.deferReply({ephemeral:true}); const guild=await client.guilds.fetch(process.env.DISCORD_GUILD_ID); const members=await guild.members.fetch();
    for(const member of members.values()) await syncMember(member);
    await interaction.editReply(`Klaar: ${members.size} Discordleden gecontroleerd.`);
  }
});
client.login(process.env.DISCORD_BOT_TOKEN);
