# HighLife localhost Discord-bot

De website gebruikt Discord OAuth2 voor de daadwerkelijke login. Deze lokale bot gebruikt dezelfde Discord-app en synchroniseert ingestelde Discord-staffrollen naar het websitepanel.

Gebruik in het Discord Developer Portal als OAuth2-redirect: `https://highlife-roleplay.evan-clark.chatgpt.site/api/auth/discord/callback`.

1. Kopieer `.env.example` naar `.env`.
2. Vul de bot-token, client-ID, server-ID, website-URL en een lange willekeurige `BOT_SYNC_SECRET` in.
3. Zet bij de bot in het Discord Developer Portal de **Server Members Intent** aan.
4. Vul de Discord-role-ID’s in die bij Administrator, Moderator en Communicatie horen.
5. Voer `npm install` en daarna `npm start` uit in deze map.

De eigenaarrol wordt nooit door de bot gewijzigd. Die blijft veilig gekoppeld aan `OWNER_DISCORD_ID`.
